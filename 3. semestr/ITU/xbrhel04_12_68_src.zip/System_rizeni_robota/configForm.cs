﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace System_rizeni_robota
{
    public partial class configForm : Form
    {
        public configForm()
        {
            InitializeComponent();
            CreateButtonList();
            menu_panel.AutoScroll = false;
            menu_panel.HorizontalScroll.Enabled = false;
            menu_panel.HorizontalScroll.Visible = false;
            menu_panel.HorizontalScroll.Maximum = 0;
            menu_panel.AutoScroll = true;

            tabControl1.Appearance = TabAppearance.FlatButtons;
            tabControl1.ItemSize = new Size(0, 1);
            tabControl1.SizeMode = TabSizeMode.Fixed;
    
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to save your progress?", "Save", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                sfg.ShowDialog();
                sfg.InitialDirectory = @".\Data";
                sfg.RestoreDirectory = true;
                this.Close();
            }
            else if (dr == DialogResult.No)
                this.Close();
        }

        private void closeBtn_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to save your progress?", "Save", MessageBoxButtons.YesNoCancel);
            if (dr == DialogResult.Yes)
            {
                sfg.ShowDialog();
                sfg.InitialDirectory = @".\Data";
                sfg.RestoreDirectory = true;
            }
            else if (dr == DialogResult.No)
                this.Close();
            else
                return;
        }

        private void maximizeBtn_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
            {
                WindowState = FormWindowState.Maximized;
            }
            else if (WindowState == FormWindowState.Maximized)
            {
                WindowState = FormWindowState.Normal;
            }
        }

        private void minimizeBtn_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        Color origClr;
        private void maximizeBtn_MouseHover(object sender, EventArgs e)
        {
            origClr = maximizeBtn.BackColor;
            maximizeBtn.BackColor = Color.DimGray;
        }

        private void maximizeBtn_MouseLeave(object sender, EventArgs e)
        {
            maximizeBtn.BackColor = origClr;
        }

        //Pro pohyb bez borderu
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        //Import .dll souborů pro pohyb bez borderu
        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        private void dragpanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(this.Handle, WM_NCLBUTTONDOWN, new IntPtr(HT_CAPTION), IntPtr.Zero);
            }
        }

        private void menuBtn_Click(object sender, EventArgs e)
        {

            if (menu_panel.Visible == false)
            {
                menu_panel.Visible = true;
                menuBtn.Location = new Point(238, 29);
                tabControl1.Size = new Size(703, 576);
                tabControl1.Location = new Point(258, 33);

                // TODO: predelat ikonu na levou sipku menuBtn.Image = ....;
            }
            else
            {
                menu_panel.Visible = false;
                menuBtn.Location = new Point(1, 29);
                tabControl1.Size = new Size(936, 576);
                tabControl1.Location = new Point(26, 33);
                //predelat ikonu na pravou sipku
            }

        }

        List<Button> listbtn = new List<Button>();
        List<PictureBox> listpic = new List<PictureBox>();
        private void CreateButtonList()
        {
            listbtn.Add(motorBtn);
            listbtn.Add(gpsBtn);
            listbtn.Add(batteryBtn);
            listbtn.Add(wheelsBtn);
            listbtn.Add(lightBtn);
            listbtn.Add(rcBtn);
            listbtn.Add(hornBtn);

            listpic.Add(motorBtnPic);
            listpic.Add(gpsBtnPic);
            listpic.Add(batteryBtnPic);
            listpic.Add(wheelsBtnPic);
            listpic.Add(lightsBtnPic);
            listpic.Add(rcBtnPic);
            listpic.Add(hornBtnPic);

        }

        private void resetSelectedBtns()
        {
            listbtn.ForEach(delegate (Button btn)
            {
                btn.BackColor = Color.DimGray;
                btn.ForeColor = Color.Gainsboro;
            });

            listpic.ForEach(delegate (PictureBox pic)
            {
                pic.BackColor = Color.DimGray;
            });
        }
        private void motor_Click(object sender, EventArgs e)
        {
            resetSelectedBtns();
            motorBtnPic.BackColor = Color.Gainsboro;
            motorBtn.ForeColor = Color.DimGray;
            motorBtn.BackColor = Color.Gainsboro;


            tabControl1.SelectedIndex = 0;
        }
        private void gpsBtn_click(object sender, EventArgs e)
        {
            resetSelectedBtns();
            gpsBtnPic.BackColor = Color.Gainsboro;
            gpsBtn.ForeColor = Color.DimGray;
            gpsBtn.BackColor = Color.Gainsboro;


            tabControl1.SelectedIndex = 1;
        }

        private void batteryBtn_click(object sender, EventArgs e)
        {
            resetSelectedBtns();
            batteryBtnPic.BackColor = Color.Gainsboro;
            batteryBtn.ForeColor = Color.DimGray;
            batteryBtn.BackColor = Color.Gainsboro;

            tabControl1.SelectedIndex = 2;
        }

        private void wheelsBtn_click(object sender, EventArgs e)
        {
            resetSelectedBtns();
            wheelsBtnPic.BackColor = Color.Gainsboro;
            wheelsBtn.ForeColor = Color.DimGray;
            wheelsBtn.BackColor = Color.Gainsboro;

            tabControl1.SelectedIndex = 3;
        }

        private void lightBtn_click(object sender, EventArgs e)
        {
            resetSelectedBtns();
            lightsBtnPic.BackColor = Color.Gainsboro;
            lightBtn.ForeColor = Color.DimGray;
            lightBtn.BackColor = Color.Gainsboro;

            tabControl1.SelectedIndex = 4;
        }

        private void rcBtn_click(object sender, EventArgs e)
        {
            resetSelectedBtns();
            rcBtnPic.BackColor = Color.Gainsboro;
            rcBtn.ForeColor = Color.DimGray;
            rcBtn.BackColor = Color.Gainsboro;

            tabControl1.SelectedIndex = 5;
        }

        private void hornBtn_click(object sender, EventArgs e)
        {
            resetSelectedBtns();
            hornBtnPic.BackColor = Color.Gainsboro;
            hornBtn.ForeColor = Color.DimGray;
            hornBtn.BackColor = Color.Gainsboro;

            tabControl1.SelectedIndex = 6;
        }

        private void menuBtn_MouseEnter(object sender, EventArgs e)
        {
            menuBtn.BackColor = Color.Gray;

            tabControl1.SelectedIndex = 7;
        }

        private void menuBtn_MouseLeave(object sender, EventArgs e)
        {
            menuBtn.BackColor = Color.DimGray;
        }

        private void MotorCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (MotorCombo.Text == "Asynchronous")
            {
                Image i = Image.FromFile("a.png");
                panelMotorImage.BackgroundImage = i;
            }

            if (MotorCombo.Text == "Stepper")
            {
                Image i = Image.FromFile("s.png");
                panelMotorImage.BackgroundImage = i;
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (MotorCombo1.Text == "Asynchronous")
            {
                Image i = Image.FromFile("a.png");
                panelMotorImage1.BackgroundImage = i;
            }

            if (MotorCombo1.Text == "Stepper")
            {
                Image i = Image.FromFile("s.png");
                panelMotorImage1.BackgroundImage = i;
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (MotorCombo2.Text == "Asynchronous")
            {
                Image i = Image.FromFile("a.png");
                panelMotorImage2.BackgroundImage = i;
            }

            if (MotorCombo2.Text == "Stepper")
            {
                Image i = Image.FromFile("s.png");
                panelMotorImage2.BackgroundImage = i;
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (MotorCombo3.Text == "Asynchronous")
            {
                Image i = Image.FromFile("a.png");
                panelMotorImage3.BackgroundImage = i;
            }

            if (MotorCombo3.Text == "Stepper")
            {
                Image i = Image.FromFile("s.png");
                panelMotorImage3.BackgroundImage = i;
            }
        }

        private void numericUpDown5_ValueChanged(object sender, EventArgs e)
        {
            if (Decimal.ToInt32(motorCount.Value) == 1)
            {
                panel2.Visible = false;
                panel3.Visible = false;
                panel4.Visible = false;
            }
            if (Decimal.ToInt32(motorCount.Value) == 2)
            {
                panel2.Visible = true;
                panel3.Visible = false;
                panel4.Visible = false;
            }
            if (Decimal.ToInt32(motorCount.Value) == 3)
            {
                panel2.Visible = true;
                panel3.Visible = true;
                panel4.Visible = false;
            }
            if (Decimal.ToInt32(motorCount.Value) == 4)
            {
                panel2.Visible = true;
                panel3.Visible = true;
                panel4.Visible = true;
            }
        }

        private void wheelCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (wheelCombo.Text == "Stock")
            {
                Image i = Image.FromFile("w1.png");
                wheelLabel.BackgroundImage = i;
            }

            if (wheelCombo.Text == "Street")
            {
                Image i = Image.FromFile("w2.png");
                wheelLabel.BackgroundImage = i;
            }

            if (wheelCombo.Text == "OffRoad")
            {
                Image i = Image.FromFile("w3.png");
                wheelLabel.BackgroundImage = i;
            }
        }

        private bool rcActive = false;
        private void generateMapBtn_MouseDown(object sender, MouseEventArgs e)
        {
            rcActive = !rcActive;

            if (rcActive)
            {
                rcToogle.BackColor = Color.Green;
                rcToogle.Text = "Remote Control: ON";
            }
            else
            {
                rcToogle.BackColor = Color.Red;
                rcToogle.Text = "Remote Control: OFF";
            }
        }


        private bool hornActive = false;
        private void button1_MouseDown(object sender, MouseEventArgs e)
        {

            hornActive = !hornActive;

            if (hornActive)
            {
                hornToogle.BackColor = Color.Green;
                hornToogle.Text = "Horn: ON";
            }
            else
            {
                hornToogle.BackColor = Color.Red;
                hornToogle.Text = "Horn: OFF";
            }
        }

        private bool gpsActive = false;
        private void gpsToogle_MouseDown(object sender, MouseEventArgs e)
        {
            gpsActive = !gpsActive;

            if (gpsActive)
            {
                gpsToogle.BackColor = Color.Green;
                gpsToogle.Text = "GPS: ON";
            }
            else
            {
                gpsToogle.BackColor = Color.Red;
                gpsToogle.Text = "GPS: OFF";
            }
        }
    }
}
