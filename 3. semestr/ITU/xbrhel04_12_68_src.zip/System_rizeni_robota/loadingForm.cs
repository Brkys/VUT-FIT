﻿using System;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace System_rizeni_robota
{
    public partial class loadingForm : Form
    {
        //Import .dll souboru, kvůli vykreslení Formu do oválu
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr RoundRect(   
           int nLeftRect,
           int nTopRect,
           int nRightRect, 
           int nBottomRect,
           int nWidthEllipse,
           int nHeightEllipse
           );

        public loadingForm()
        {
            InitializeComponent();
            //Vykreslení formu do oválu
            Region = System.Drawing.Region.FromHrgn(RoundRect(0, 0, Width, Height, 30, 30));
        }

        //Kvůli minulému debuggu
        //private void progressBar1_Click(object sender, EventArgs e) { }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            //Simulace načítání
            progressBar1.Value++;
            if (progressBar1.Value > 50)
                progressBar1.Value++;
            if (progressBar1.Value == 100)
            {
            
                simulation_Timer.Enabled = false;
                //Otevření nového formu a předání argumentu při zavřítí, aby se zavřel i rodičovský form
                //+ předání pár parametrů pro zdědění
                this.Hide();
                loginForm form = new loginForm();
                form.FormClosed += (s, args) => this.Close();
                form.BackColor = this.BackColor;
                form.ForeColor = this.ForeColor;
                form.FormBorderStyle = this.FormBorderStyle;
                form.StartPosition = this.StartPosition;
                form.Show();
            }    
            if (progressBar1.Value < 25)
                label1.Text = "Loading interface...";
            else if (progressBar1.Value < 51)
                label1.Text = "Loading saves...";
            else if (progressBar1.Value < 94)
                label1.Text = "Launching system...";
            else
                label1.Text = "Finishing...";
        }
    }
}
