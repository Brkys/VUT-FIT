﻿namespace System_rizeni_robota
{
    partial class configForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(configForm));
            this.menu_panel = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.hornBtnPic = new System.Windows.Forms.PictureBox();
            this.rcBtnPic = new System.Windows.Forms.PictureBox();
            this.lightsBtnPic = new System.Windows.Forms.PictureBox();
            this.motorBtnPic = new System.Windows.Forms.PictureBox();
            this.gpsBtnPic = new System.Windows.Forms.PictureBox();
            this.wheelsBtnPic = new System.Windows.Forms.PictureBox();
            this.batteryBtnPic = new System.Windows.Forms.PictureBox();
            this.hornBtn = new System.Windows.Forms.Button();
            this.rcBtn = new System.Windows.Forms.Button();
            this.lightBtn = new System.Windows.Forms.Button();
            this.wheelsBtn = new System.Windows.Forms.Button();
            this.gpsBtn = new System.Windows.Forms.Button();
            this.batteryBtn = new System.Windows.Forms.Button();
            this.motorBtn = new System.Windows.Forms.Button();
            this.menuBtn = new System.Windows.Forms.PictureBox();
            this.dragpanel = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.saveConfigBtn = new System.Windows.Forms.PictureBox();
            this.closeBtn = new System.Windows.Forms.PictureBox();
            this.maximizeBtn = new System.Windows.Forms.PictureBox();
            this.minimizeBtn = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.panelMotorImage3 = new System.Windows.Forms.Panel();
            this.MotorCombo3 = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panelMotorImage2 = new System.Windows.Forms.Panel();
            this.MotorCombo2 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.panelMotorImage1 = new System.Windows.Forms.Panel();
            this.MotorCombo1 = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.panelMotorImage = new System.Windows.Forms.Panel();
            this.MotorCombo = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.sfg = new System.Windows.Forms.SaveFileDialog();
            this.motorCount = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
            this.label18 = new System.Windows.Forms.Label();
            this.numericUpDown6 = new System.Windows.Forms.NumericUpDown();
            this.label19 = new System.Windows.Forms.Label();
            this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.panel5 = new System.Windows.Forms.Panel();
            this.wheelLabel = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.numericUpDown8 = new System.Windows.Forms.NumericUpDown();
            this.wheelCombo = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.numericUpDown9 = new System.Windows.Forms.NumericUpDown();
            this.panel6 = new System.Windows.Forms.Panel();
            this.rcToogle = new System.Windows.Forms.Button();
            this.hornToogle = new System.Windows.Forms.Button();
            this.gpsToogle = new System.Windows.Forms.Button();
            this.menu_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hornBtnPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rcBtnPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lightsBtnPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.motorBtnPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gpsBtnPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wheelsBtnPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.batteryBtnPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuBtn)).BeginInit();
            this.dragpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saveConfigBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maximizeBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.minimizeBtn)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.motorCount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).BeginInit();
            this.SuspendLayout();
            // 
            // menu_panel
            // 
            this.menu_panel.BackColor = System.Drawing.Color.DimGray;
            this.menu_panel.Controls.Add(this.label2);
            this.menu_panel.Controls.Add(this.hornBtnPic);
            this.menu_panel.Controls.Add(this.rcBtnPic);
            this.menu_panel.Controls.Add(this.lightsBtnPic);
            this.menu_panel.Controls.Add(this.motorBtnPic);
            this.menu_panel.Controls.Add(this.gpsBtnPic);
            this.menu_panel.Controls.Add(this.wheelsBtnPic);
            this.menu_panel.Controls.Add(this.batteryBtnPic);
            this.menu_panel.Controls.Add(this.hornBtn);
            this.menu_panel.Controls.Add(this.rcBtn);
            this.menu_panel.Controls.Add(this.lightBtn);
            this.menu_panel.Controls.Add(this.wheelsBtn);
            this.menu_panel.Controls.Add(this.gpsBtn);
            this.menu_panel.Controls.Add(this.batteryBtn);
            this.menu_panel.Controls.Add(this.motorBtn);
            this.menu_panel.Dock = System.Windows.Forms.DockStyle.Left;
            this.menu_panel.Location = new System.Drawing.Point(0, 36);
            this.menu_panel.Margin = new System.Windows.Forms.Padding(1);
            this.menu_panel.Name = "menu_panel";
            this.menu_panel.Size = new System.Drawing.Size(315, 728);
            this.menu_panel.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 11.1F);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(16, 18);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 22);
            this.label2.TabIndex = 19;
            this.label2.Text = "Menu";
            // 
            // hornBtnPic
            // 
            this.hornBtnPic.BackColor = System.Drawing.Color.Transparent;
            this.hornBtnPic.Image = global::System_rizeni_robota.Properties.Resources.Horn_32px;
            this.hornBtnPic.Location = new System.Drawing.Point(11, 470);
            this.hornBtnPic.Margin = new System.Windows.Forms.Padding(1);
            this.hornBtnPic.Name = "hornBtnPic";
            this.hornBtnPic.Size = new System.Drawing.Size(35, 32);
            this.hornBtnPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.hornBtnPic.TabIndex = 18;
            this.hornBtnPic.TabStop = false;
            // 
            // rcBtnPic
            // 
            this.rcBtnPic.BackColor = System.Drawing.Color.Transparent;
            this.rcBtnPic.Image = global::System_rizeni_robota.Properties.Resources.Remote_Control_32px;
            this.rcBtnPic.Location = new System.Drawing.Point(11, 406);
            this.rcBtnPic.Margin = new System.Windows.Forms.Padding(1);
            this.rcBtnPic.Name = "rcBtnPic";
            this.rcBtnPic.Size = new System.Drawing.Size(35, 32);
            this.rcBtnPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.rcBtnPic.TabIndex = 17;
            this.rcBtnPic.TabStop = false;
            // 
            // lightsBtnPic
            // 
            this.lightsBtnPic.BackColor = System.Drawing.Color.Transparent;
            this.lightsBtnPic.Image = global::System_rizeni_robota.Properties.Resources.Fog_Lamp_32px;
            this.lightsBtnPic.Location = new System.Drawing.Point(11, 338);
            this.lightsBtnPic.Margin = new System.Windows.Forms.Padding(1);
            this.lightsBtnPic.Name = "lightsBtnPic";
            this.lightsBtnPic.Size = new System.Drawing.Size(35, 32);
            this.lightsBtnPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.lightsBtnPic.TabIndex = 16;
            this.lightsBtnPic.TabStop = false;
            // 
            // motorBtnPic
            // 
            this.motorBtnPic.BackColor = System.Drawing.Color.Transparent;
            this.motorBtnPic.Image = global::System_rizeni_robota.Properties.Resources.Turbocharger_32px;
            this.motorBtnPic.Location = new System.Drawing.Point(11, 68);
            this.motorBtnPic.Margin = new System.Windows.Forms.Padding(1);
            this.motorBtnPic.Name = "motorBtnPic";
            this.motorBtnPic.Size = new System.Drawing.Size(35, 32);
            this.motorBtnPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.motorBtnPic.TabIndex = 15;
            this.motorBtnPic.TabStop = false;
            // 
            // gpsBtnPic
            // 
            this.gpsBtnPic.BackColor = System.Drawing.Color.Transparent;
            this.gpsBtnPic.Image = global::System_rizeni_robota.Properties.Resources.GPS_32px;
            this.gpsBtnPic.Location = new System.Drawing.Point(11, 135);
            this.gpsBtnPic.Margin = new System.Windows.Forms.Padding(1);
            this.gpsBtnPic.Name = "gpsBtnPic";
            this.gpsBtnPic.Size = new System.Drawing.Size(35, 32);
            this.gpsBtnPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gpsBtnPic.TabIndex = 14;
            this.gpsBtnPic.TabStop = false;
            // 
            // wheelsBtnPic
            // 
            this.wheelsBtnPic.BackColor = System.Drawing.Color.Transparent;
            this.wheelsBtnPic.Image = global::System_rizeni_robota.Properties.Resources.Tire_32px;
            this.wheelsBtnPic.Location = new System.Drawing.Point(11, 272);
            this.wheelsBtnPic.Margin = new System.Windows.Forms.Padding(1);
            this.wheelsBtnPic.Name = "wheelsBtnPic";
            this.wheelsBtnPic.Size = new System.Drawing.Size(35, 32);
            this.wheelsBtnPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.wheelsBtnPic.TabIndex = 13;
            this.wheelsBtnPic.TabStop = false;
            // 
            // batteryBtnPic
            // 
            this.batteryBtnPic.BackColor = System.Drawing.Color.Transparent;
            this.batteryBtnPic.Image = global::System_rizeni_robota.Properties.Resources.Full_Battery_32px;
            this.batteryBtnPic.Location = new System.Drawing.Point(11, 203);
            this.batteryBtnPic.Margin = new System.Windows.Forms.Padding(1);
            this.batteryBtnPic.Name = "batteryBtnPic";
            this.batteryBtnPic.Size = new System.Drawing.Size(35, 32);
            this.batteryBtnPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.batteryBtnPic.TabIndex = 5;
            this.batteryBtnPic.TabStop = false;
            // 
            // hornBtn
            // 
            this.hornBtn.BackColor = System.Drawing.Color.DimGray;
            this.hornBtn.FlatAppearance.BorderSize = 0;
            this.hornBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.hornBtn.Font = new System.Drawing.Font("Century Gothic", 11.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.hornBtn.ForeColor = System.Drawing.Color.Gainsboro;
            this.hornBtn.Location = new System.Drawing.Point(0, 454);
            this.hornBtn.Margin = new System.Windows.Forms.Padding(1);
            this.hornBtn.Name = "hornBtn";
            this.hornBtn.Size = new System.Drawing.Size(313, 68);
            this.hornBtn.TabIndex = 12;
            this.hornBtn.Text = "             Horn";
            this.hornBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.hornBtn.UseVisualStyleBackColor = false;
            this.hornBtn.Click += new System.EventHandler(this.hornBtn_click);
            // 
            // rcBtn
            // 
            this.rcBtn.BackColor = System.Drawing.Color.DimGray;
            this.rcBtn.FlatAppearance.BorderSize = 0;
            this.rcBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rcBtn.Font = new System.Drawing.Font("Century Gothic", 11.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rcBtn.ForeColor = System.Drawing.Color.Gainsboro;
            this.rcBtn.Location = new System.Drawing.Point(0, 389);
            this.rcBtn.Margin = new System.Windows.Forms.Padding(1);
            this.rcBtn.Name = "rcBtn";
            this.rcBtn.Size = new System.Drawing.Size(313, 68);
            this.rcBtn.TabIndex = 11;
            this.rcBtn.Text = "             Remote Control";
            this.rcBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.rcBtn.UseVisualStyleBackColor = false;
            this.rcBtn.Click += new System.EventHandler(this.rcBtn_click);
            // 
            // lightBtn
            // 
            this.lightBtn.BackColor = System.Drawing.Color.DimGray;
            this.lightBtn.FlatAppearance.BorderSize = 0;
            this.lightBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lightBtn.Font = new System.Drawing.Font("Century Gothic", 11.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lightBtn.ForeColor = System.Drawing.Color.Gainsboro;
            this.lightBtn.Location = new System.Drawing.Point(0, 320);
            this.lightBtn.Margin = new System.Windows.Forms.Padding(1);
            this.lightBtn.Name = "lightBtn";
            this.lightBtn.Size = new System.Drawing.Size(313, 68);
            this.lightBtn.TabIndex = 10;
            this.lightBtn.Text = "             Lights";
            this.lightBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lightBtn.UseVisualStyleBackColor = false;
            this.lightBtn.Click += new System.EventHandler(this.lightBtn_click);
            // 
            // wheelsBtn
            // 
            this.wheelsBtn.BackColor = System.Drawing.Color.DimGray;
            this.wheelsBtn.FlatAppearance.BorderSize = 0;
            this.wheelsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.wheelsBtn.Font = new System.Drawing.Font("Century Gothic", 11.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.wheelsBtn.ForeColor = System.Drawing.Color.Gainsboro;
            this.wheelsBtn.Location = new System.Drawing.Point(0, 252);
            this.wheelsBtn.Margin = new System.Windows.Forms.Padding(1);
            this.wheelsBtn.Name = "wheelsBtn";
            this.wheelsBtn.Size = new System.Drawing.Size(313, 68);
            this.wheelsBtn.TabIndex = 9;
            this.wheelsBtn.Text = "             Wheels";
            this.wheelsBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.wheelsBtn.UseVisualStyleBackColor = false;
            this.wheelsBtn.Click += new System.EventHandler(this.wheelsBtn_click);
            // 
            // gpsBtn
            // 
            this.gpsBtn.BackColor = System.Drawing.Color.DimGray;
            this.gpsBtn.FlatAppearance.BorderSize = 0;
            this.gpsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gpsBtn.Font = new System.Drawing.Font("Century Gothic", 11.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.gpsBtn.ForeColor = System.Drawing.Color.Gainsboro;
            this.gpsBtn.Location = new System.Drawing.Point(0, 118);
            this.gpsBtn.Margin = new System.Windows.Forms.Padding(1);
            this.gpsBtn.Name = "gpsBtn";
            this.gpsBtn.Size = new System.Drawing.Size(313, 68);
            this.gpsBtn.TabIndex = 8;
            this.gpsBtn.Text = "             GPS Tracker";
            this.gpsBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.gpsBtn.UseVisualStyleBackColor = false;
            this.gpsBtn.Click += new System.EventHandler(this.gpsBtn_click);
            // 
            // batteryBtn
            // 
            this.batteryBtn.BackColor = System.Drawing.Color.DimGray;
            this.batteryBtn.FlatAppearance.BorderSize = 0;
            this.batteryBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.batteryBtn.Font = new System.Drawing.Font("Century Gothic", 11.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.batteryBtn.ForeColor = System.Drawing.Color.Gainsboro;
            this.batteryBtn.Location = new System.Drawing.Point(0, 186);
            this.batteryBtn.Margin = new System.Windows.Forms.Padding(1);
            this.batteryBtn.Name = "batteryBtn";
            this.batteryBtn.Size = new System.Drawing.Size(313, 68);
            this.batteryBtn.TabIndex = 7;
            this.batteryBtn.Text = "             Battery";
            this.batteryBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.batteryBtn.UseVisualStyleBackColor = false;
            this.batteryBtn.Click += new System.EventHandler(this.batteryBtn_click);
            // 
            // motorBtn
            // 
            this.motorBtn.BackColor = System.Drawing.Color.DimGray;
            this.motorBtn.FlatAppearance.BorderSize = 0;
            this.motorBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.motorBtn.Font = new System.Drawing.Font("Century Gothic", 11.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.motorBtn.ForeColor = System.Drawing.Color.Gainsboro;
            this.motorBtn.Location = new System.Drawing.Point(0, 52);
            this.motorBtn.Margin = new System.Windows.Forms.Padding(1);
            this.motorBtn.Name = "motorBtn";
            this.motorBtn.Size = new System.Drawing.Size(313, 68);
            this.motorBtn.TabIndex = 0;
            this.motorBtn.Tag = "";
            this.motorBtn.Text = "             Motor";
            this.motorBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.motorBtn.UseVisualStyleBackColor = false;
            this.motorBtn.Click += new System.EventHandler(this.motor_Click);
            // 
            // menuBtn
            // 
            this.menuBtn.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.menuBtn.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.menuBtn.Location = new System.Drawing.Point(316, 36);
            this.menuBtn.Margin = new System.Windows.Forms.Padding(1);
            this.menuBtn.Name = "menuBtn";
            this.menuBtn.Size = new System.Drawing.Size(23, 729);
            this.menuBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.menuBtn.TabIndex = 6;
            this.menuBtn.TabStop = false;
            this.menuBtn.Click += new System.EventHandler(this.menuBtn_Click);
            this.menuBtn.MouseEnter += new System.EventHandler(this.menuBtn_MouseEnter);
            this.menuBtn.MouseLeave += new System.EventHandler(this.menuBtn_MouseLeave);
            // 
            // dragpanel
            // 
            this.dragpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.dragpanel.Controls.Add(this.pictureBox1);
            this.dragpanel.Controls.Add(this.saveConfigBtn);
            this.dragpanel.Controls.Add(this.closeBtn);
            this.dragpanel.Controls.Add(this.maximizeBtn);
            this.dragpanel.Controls.Add(this.minimizeBtn);
            this.dragpanel.Controls.Add(this.label1);
            this.dragpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.dragpanel.Location = new System.Drawing.Point(0, 0);
            this.dragpanel.Margin = new System.Windows.Forms.Padding(1);
            this.dragpanel.Name = "dragpanel";
            this.dragpanel.Size = new System.Drawing.Size(1297, 36);
            this.dragpanel.TabIndex = 2;
            this.dragpanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dragpanel_MouseMove);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Image = global::System_rizeni_robota.Properties.Resources.RoboUI;
            this.pictureBox1.Location = new System.Drawing.Point(0, 1);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(168, 34);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // saveConfigBtn
            // 
            this.saveConfigBtn.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.saveConfigBtn.BackColor = System.Drawing.Color.Transparent;
            this.saveConfigBtn.Image = global::System_rizeni_robota.Properties.Resources.Save_32px;
            this.saveConfigBtn.Location = new System.Drawing.Point(1161, 0);
            this.saveConfigBtn.Margin = new System.Windows.Forms.Padding(1);
            this.saveConfigBtn.Name = "saveConfigBtn";
            this.saveConfigBtn.Size = new System.Drawing.Size(35, 36);
            this.saveConfigBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.saveConfigBtn.TabIndex = 3;
            this.saveConfigBtn.TabStop = false;
            this.saveConfigBtn.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // closeBtn
            // 
            this.closeBtn.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.closeBtn.BackColor = System.Drawing.Color.Firebrick;
            this.closeBtn.Image = global::System_rizeni_robota.Properties.Resources.Close_Window_32px;
            this.closeBtn.Location = new System.Drawing.Point(1261, 0);
            this.closeBtn.Margin = new System.Windows.Forms.Padding(1);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(35, 36);
            this.closeBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.closeBtn.TabIndex = 4;
            this.closeBtn.TabStop = false;
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // maximizeBtn
            // 
            this.maximizeBtn.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.maximizeBtn.BackColor = System.Drawing.Color.Transparent;
            this.maximizeBtn.Image = global::System_rizeni_robota.Properties.Resources.Maximize_Window_32px;
            this.maximizeBtn.Location = new System.Drawing.Point(1227, 0);
            this.maximizeBtn.Margin = new System.Windows.Forms.Padding(1);
            this.maximizeBtn.Name = "maximizeBtn";
            this.maximizeBtn.Size = new System.Drawing.Size(35, 36);
            this.maximizeBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.maximizeBtn.TabIndex = 6;
            this.maximizeBtn.TabStop = false;
            this.maximizeBtn.Click += new System.EventHandler(this.maximizeBtn_Click);
            this.maximizeBtn.MouseLeave += new System.EventHandler(this.maximizeBtn_MouseLeave);
            this.maximizeBtn.MouseHover += new System.EventHandler(this.maximizeBtn_MouseHover);
            // 
            // minimizeBtn
            // 
            this.minimizeBtn.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.minimizeBtn.BackColor = System.Drawing.Color.Transparent;
            this.minimizeBtn.Image = global::System_rizeni_robota.Properties.Resources.Minimize_Window_32px;
            this.minimizeBtn.Location = new System.Drawing.Point(1193, 0);
            this.minimizeBtn.Margin = new System.Windows.Forms.Padding(1);
            this.minimizeBtn.Name = "minimizeBtn";
            this.minimizeBtn.Size = new System.Drawing.Size(35, 36);
            this.minimizeBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.minimizeBtn.TabIndex = 5;
            this.minimizeBtn.TabStop = false;
            this.minimizeBtn.Click += new System.EventHandler(this.minimizeBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(141, 12);
            this.label1.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 17);
            this.label1.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Location = new System.Drawing.Point(344, 41);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(937, 709);
            this.tabControl1.TabIndex = 7;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Silver;
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.motorCount);
            this.tabPage1.Controls.Add(this.panel4);
            this.tabPage1.Controls.Add(this.panel3);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(0);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(929, 680);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Motor";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.panelMotorImage3);
            this.panel4.Controls.Add(this.MotorCombo3);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.numericUpDown4);
            this.panel4.Location = new System.Drawing.Point(708, 196);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(214, 362);
            this.panel4.TabIndex = 10;
            this.panel4.Visible = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label15.Location = new System.Drawing.Point(65, 17);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(80, 22);
            this.label15.TabIndex = 9;
            this.label15.Text = "Motor 4";
            // 
            // panelMotorImage3
            // 
            this.panelMotorImage3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelMotorImage3.Location = new System.Drawing.Point(19, 188);
            this.panelMotorImage3.Name = "panelMotorImage3";
            this.panelMotorImage3.Size = new System.Drawing.Size(177, 159);
            this.panelMotorImage3.TabIndex = 8;
            // 
            // MotorCombo3
            // 
            this.MotorCombo3.BackColor = System.Drawing.Color.Silver;
            this.MotorCombo3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MotorCombo3.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MotorCombo3.FormattingEnabled = true;
            this.MotorCombo3.Items.AddRange(new object[] {
            "Asynchronous",
            "Stepper"});
            this.MotorCombo3.Location = new System.Drawing.Point(43, 109);
            this.MotorCombo3.Name = "MotorCombo3";
            this.MotorCombo3.Size = new System.Drawing.Size(121, 25);
            this.MotorCombo3.TabIndex = 7;
            this.MotorCombo3.Text = "Motor Type";
            this.MotorCombo3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label16.Location = new System.Drawing.Point(15, 66);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(102, 19);
            this.label16.TabIndex = 6;
            this.label16.Text = "Power(watts):";
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numericUpDown4.BackColor = System.Drawing.Color.Silver;
            this.numericUpDown4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDown4.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.numericUpDown4.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown4.Location = new System.Drawing.Point(124, 68);
            this.numericUpDown4.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(51, 19);
            this.numericUpDown4.TabIndex = 5;
            this.numericUpDown4.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.panelMotorImage2);
            this.panel3.Controls.Add(this.MotorCombo2);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.numericUpDown3);
            this.panel3.Location = new System.Drawing.Point(488, 196);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(214, 362);
            this.panel3.TabIndex = 10;
            this.panel3.Visible = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label12.Location = new System.Drawing.Point(65, 17);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(80, 22);
            this.label12.TabIndex = 9;
            this.label12.Text = "Motor 3";
            // 
            // panelMotorImage2
            // 
            this.panelMotorImage2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelMotorImage2.Location = new System.Drawing.Point(19, 188);
            this.panelMotorImage2.Name = "panelMotorImage2";
            this.panelMotorImage2.Size = new System.Drawing.Size(177, 159);
            this.panelMotorImage2.TabIndex = 8;
            // 
            // MotorCombo2
            // 
            this.MotorCombo2.BackColor = System.Drawing.Color.Silver;
            this.MotorCombo2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MotorCombo2.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MotorCombo2.FormattingEnabled = true;
            this.MotorCombo2.Items.AddRange(new object[] {
            "Asynchronous",
            "Stepper"});
            this.MotorCombo2.Location = new System.Drawing.Point(43, 109);
            this.MotorCombo2.Name = "MotorCombo2";
            this.MotorCombo2.Size = new System.Drawing.Size(121, 25);
            this.MotorCombo2.TabIndex = 7;
            this.MotorCombo2.Text = "Motor Type";
            this.MotorCombo2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label14.Location = new System.Drawing.Point(15, 66);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(102, 19);
            this.label14.TabIndex = 6;
            this.label14.Text = "Power(watts):";
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numericUpDown3.BackColor = System.Drawing.Color.Silver;
            this.numericUpDown3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDown3.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.numericUpDown3.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown3.Location = new System.Drawing.Point(124, 68);
            this.numericUpDown3.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(51, 19);
            this.numericUpDown3.TabIndex = 5;
            this.numericUpDown3.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.panelMotorImage1);
            this.panel2.Controls.Add(this.MotorCombo1);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.numericUpDown2);
            this.panel2.Location = new System.Drawing.Point(227, 196);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(214, 362);
            this.panel2.TabIndex = 10;
            this.panel2.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label10.Location = new System.Drawing.Point(65, 17);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(80, 22);
            this.label10.TabIndex = 9;
            this.label10.Text = "Motor 2";
            // 
            // panelMotorImage1
            // 
            this.panelMotorImage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelMotorImage1.Location = new System.Drawing.Point(19, 188);
            this.panelMotorImage1.Name = "panelMotorImage1";
            this.panelMotorImage1.Size = new System.Drawing.Size(177, 159);
            this.panelMotorImage1.TabIndex = 8;
            // 
            // MotorCombo1
            // 
            this.MotorCombo1.BackColor = System.Drawing.Color.Silver;
            this.MotorCombo1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MotorCombo1.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MotorCombo1.FormattingEnabled = true;
            this.MotorCombo1.Items.AddRange(new object[] {
            "Asynchronous",
            "Stepper"});
            this.MotorCombo1.Location = new System.Drawing.Point(43, 109);
            this.MotorCombo1.Name = "MotorCombo1";
            this.MotorCombo1.Size = new System.Drawing.Size(121, 25);
            this.MotorCombo1.TabIndex = 7;
            this.MotorCombo1.Text = "Motor Type";
            this.MotorCombo1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label11.Location = new System.Drawing.Point(15, 66);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(102, 19);
            this.label11.TabIndex = 6;
            this.label11.Text = "Power(watts):";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numericUpDown2.BackColor = System.Drawing.Color.Silver;
            this.numericUpDown2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDown2.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.numericUpDown2.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown2.Location = new System.Drawing.Point(124, 68);
            this.numericUpDown2.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(51, 19);
            this.numericUpDown2.TabIndex = 5;
            this.numericUpDown2.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.panelMotorImage);
            this.panel1.Controls.Add(this.MotorCombo);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.numericUpDown1);
            this.panel1.Location = new System.Drawing.Point(7, 196);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(214, 362);
            this.panel1.TabIndex = 0;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label13.Location = new System.Drawing.Point(65, 17);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(80, 22);
            this.label13.TabIndex = 9;
            this.label13.Text = "Motor 1";
            // 
            // panelMotorImage
            // 
            this.panelMotorImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelMotorImage.Location = new System.Drawing.Point(19, 188);
            this.panelMotorImage.Name = "panelMotorImage";
            this.panelMotorImage.Size = new System.Drawing.Size(177, 159);
            this.panelMotorImage.TabIndex = 8;
            // 
            // MotorCombo
            // 
            this.MotorCombo.BackColor = System.Drawing.Color.Silver;
            this.MotorCombo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MotorCombo.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MotorCombo.FormattingEnabled = true;
            this.MotorCombo.Items.AddRange(new object[] {
            "Asynchronous",
            "Stepper"});
            this.MotorCombo.Location = new System.Drawing.Point(43, 109);
            this.MotorCombo.Name = "MotorCombo";
            this.MotorCombo.Size = new System.Drawing.Size(121, 25);
            this.MotorCombo.TabIndex = 7;
            this.MotorCombo.Text = "Motor Type";
            this.MotorCombo.SelectedIndexChanged += new System.EventHandler(this.MotorCombo_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(15, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 19);
            this.label4.TabIndex = 6;
            this.label4.Text = "Power(watts):";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numericUpDown1.BackColor = System.Drawing.Color.Silver;
            this.numericUpDown1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDown1.Font = new System.Drawing.Font("Century Gothic", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.numericUpDown1.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown1.Location = new System.Drawing.Point(124, 68);
            this.numericUpDown1.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(51, 19);
            this.numericUpDown1.TabIndex = 5;
            this.numericUpDown1.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Silver;
            this.tabPage2.Controls.Add(this.gpsToogle);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(929, 680);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "GPS";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Silver;
            this.tabPage3.Controls.Add(this.panel5);
            this.tabPage3.Controls.Add(this.label20);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Controls.Add(this.numericUpDown7);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.numericUpDown6);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.numericUpDown5);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(929, 680);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Battery";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Silver;
            this.tabPage4.Controls.Add(this.wheelCombo);
            this.tabPage4.Controls.Add(this.wheelLabel);
            this.tabPage4.Controls.Add(this.label21);
            this.tabPage4.Controls.Add(this.numericUpDown8);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(929, 680);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Wheels";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.Silver;
            this.tabPage5.Controls.Add(this.panel6);
            this.tabPage5.Controls.Add(this.numericUpDown9);
            this.tabPage5.Controls.Add(this.label6);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(929, 680);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Lights";
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.Silver;
            this.tabPage6.Controls.Add(this.rcToogle);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(929, 680);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Remote control";
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.Color.Silver;
            this.tabPage7.Controls.Add(this.hornToogle);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(929, 680);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Horn";
            // 
            // sfg
            // 
            this.sfg.Filter = "RoboUI files | *.settings";
            this.sfg.Title = "Save file";
            // 
            // motorCount
            // 
            this.motorCount.BackColor = System.Drawing.Color.Silver;
            this.motorCount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.motorCount.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.motorCount.Location = new System.Drawing.Point(213, 61);
            this.motorCount.Margin = new System.Windows.Forms.Padding(4);
            this.motorCount.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.motorCount.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.motorCount.Name = "motorCount";
            this.motorCount.Size = new System.Drawing.Size(51, 32);
            this.motorCount.TabIndex = 10;
            this.motorCount.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.motorCount.ValueChanged += new System.EventHandler(this.numericUpDown5_ValueChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label17.Location = new System.Drawing.Point(21, 60);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(171, 30);
            this.label17.TabIndex = 10;
            this.label17.Text = "Motor Count:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(48, 126);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(230, 30);
            this.label5.TabIndex = 11;
            this.label5.Text = "Battery cell count:";
            // 
            // numericUpDown5
            // 
            this.numericUpDown5.BackColor = System.Drawing.Color.Silver;
            this.numericUpDown5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDown5.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.numericUpDown5.Location = new System.Drawing.Point(344, 124);
            this.numericUpDown5.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown5.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.numericUpDown5.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown5.Name = "numericUpDown5";
            this.numericUpDown5.Size = new System.Drawing.Size(51, 32);
            this.numericUpDown5.TabIndex = 12;
            this.numericUpDown5.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label18.Location = new System.Drawing.Point(48, 222);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(255, 30);
            this.label18.TabIndex = 13;
            this.label18.Text = "Cell capacity (mAh)";
            // 
            // numericUpDown6
            // 
            this.numericUpDown6.BackColor = System.Drawing.Color.Silver;
            this.numericUpDown6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDown6.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.numericUpDown6.Increment = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.numericUpDown6.Location = new System.Drawing.Point(319, 223);
            this.numericUpDown6.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown6.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown6.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown6.Name = "numericUpDown6";
            this.numericUpDown6.Size = new System.Drawing.Size(76, 32);
            this.numericUpDown6.TabIndex = 14;
            this.numericUpDown6.Value = new decimal(new int[] {
            1100,
            0,
            0,
            0});
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label19.Location = new System.Drawing.Point(48, 328);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(202, 30);
            this.label19.TabIndex = 15;
            this.label19.Text = "Cell voltage (V)";
            // 
            // numericUpDown7
            // 
            this.numericUpDown7.BackColor = System.Drawing.Color.Silver;
            this.numericUpDown7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDown7.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.numericUpDown7.Location = new System.Drawing.Point(344, 328);
            this.numericUpDown7.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown7.Maximum = new decimal(new int[] {
            25,
            0,
            0,
            0});
            this.numericUpDown7.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown7.Name = "numericUpDown7";
            this.numericUpDown7.Size = new System.Drawing.Size(51, 32);
            this.numericUpDown7.TabIndex = 16;
            this.numericUpDown7.Value = new decimal(new int[] {
            7,
            0,
            0,
            0});
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(0, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(54, 17);
            this.label20.TabIndex = 17;
            this.label20.Text = "label20";
            // 
            // panel5
            // 
            this.panel5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel5.BackgroundImage")));
            this.panel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel5.Location = new System.Drawing.Point(477, 71);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(310, 347);
            this.panel5.TabIndex = 18;
            // 
            // wheelLabel
            // 
            this.wheelLabel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.wheelLabel.Location = new System.Drawing.Point(462, 122);
            this.wheelLabel.Name = "wheelLabel";
            this.wheelLabel.Size = new System.Drawing.Size(300, 300);
            this.wheelLabel.TabIndex = 22;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label21.Location = new System.Drawing.Point(83, 222);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(196, 34);
            this.label21.TabIndex = 19;
            this.label21.Text = "Wheel count:";
            // 
            // numericUpDown8
            // 
            this.numericUpDown8.BackColor = System.Drawing.Color.Silver;
            this.numericUpDown8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDown8.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.numericUpDown8.Increment = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDown8.Location = new System.Drawing.Point(298, 223);
            this.numericUpDown8.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown8.Maximum = new decimal(new int[] {
            64,
            0,
            0,
            0});
            this.numericUpDown8.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDown8.Name = "numericUpDown8";
            this.numericUpDown8.Size = new System.Drawing.Size(51, 37);
            this.numericUpDown8.TabIndex = 20;
            this.numericUpDown8.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // wheelCombo
            // 
            this.wheelCombo.BackColor = System.Drawing.Color.Silver;
            this.wheelCombo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.wheelCombo.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.wheelCombo.FormattingEnabled = true;
            this.wheelCombo.Items.AddRange(new object[] {
            "Stock",
            "Street",
            "OffRoad"});
            this.wheelCombo.Location = new System.Drawing.Point(89, 290);
            this.wheelCombo.Name = "wheelCombo";
            this.wheelCombo.Size = new System.Drawing.Size(260, 41);
            this.wheelCombo.TabIndex = 23;
            this.wheelCombo.Text = "Wheel Type";
            this.wheelCombo.SelectedIndexChanged += new System.EventHandler(this.wheelCombo_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(113, 268);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(187, 34);
            this.label6.TabIndex = 20;
            this.label6.Text = "Lights count:";
            // 
            // numericUpDown9
            // 
            this.numericUpDown9.BackColor = System.Drawing.Color.Silver;
            this.numericUpDown9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDown9.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.numericUpDown9.Increment = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDown9.Location = new System.Drawing.Point(316, 269);
            this.numericUpDown9.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown9.Maximum = new decimal(new int[] {
            64,
            0,
            0,
            0});
            this.numericUpDown9.Name = "numericUpDown9";
            this.numericUpDown9.Size = new System.Drawing.Size(51, 37);
            this.numericUpDown9.TabIndex = 21;
            this.numericUpDown9.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // panel6
            // 
            this.panel6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel6.BackgroundImage")));
            this.panel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel6.Location = new System.Drawing.Point(464, 173);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(250, 250);
            this.panel6.TabIndex = 22;
            // 
            // rcToogle
            // 
            this.rcToogle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.rcToogle.BackColor = System.Drawing.Color.Red;
            this.rcToogle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rcToogle.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rcToogle.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.rcToogle.Location = new System.Drawing.Point(254, 257);
            this.rcToogle.Margin = new System.Windows.Forms.Padding(4);
            this.rcToogle.Name = "rcToogle";
            this.rcToogle.Size = new System.Drawing.Size(400, 57);
            this.rcToogle.TabIndex = 10;
            this.rcToogle.Text = "Remote Control: OFF";
            this.rcToogle.UseVisualStyleBackColor = false;
            this.rcToogle.MouseDown += new System.Windows.Forms.MouseEventHandler(this.generateMapBtn_MouseDown);
            // 
            // hornToogle
            // 
            this.hornToogle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.hornToogle.BackColor = System.Drawing.Color.Red;
            this.hornToogle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.hornToogle.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.hornToogle.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.hornToogle.Location = new System.Drawing.Point(254, 257);
            this.hornToogle.Margin = new System.Windows.Forms.Padding(4);
            this.hornToogle.Name = "hornToogle";
            this.hornToogle.Size = new System.Drawing.Size(400, 57);
            this.hornToogle.TabIndex = 11;
            this.hornToogle.Text = "Horn: OFF";
            this.hornToogle.UseVisualStyleBackColor = false;
            this.hornToogle.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button1_MouseDown);
            // 
            // gpsToogle
            // 
            this.gpsToogle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.gpsToogle.BackColor = System.Drawing.Color.Red;
            this.gpsToogle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gpsToogle.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.gpsToogle.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.gpsToogle.Location = new System.Drawing.Point(254, 257);
            this.gpsToogle.Margin = new System.Windows.Forms.Padding(4);
            this.gpsToogle.Name = "gpsToogle";
            this.gpsToogle.Size = new System.Drawing.Size(400, 57);
            this.gpsToogle.TabIndex = 12;
            this.gpsToogle.Text = "GPS: OFF";
            this.gpsToogle.UseVisualStyleBackColor = false;
            this.gpsToogle.MouseDown += new System.Windows.Forms.MouseEventHandler(this.gpsToogle_MouseDown);
            // 
            // configForm
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1297, 764);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menu_panel);
            this.Controls.Add(this.dragpanel);
            this.Controls.Add(this.menuBtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(1);
            this.Name = "configForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "configForm";
            this.menu_panel.ResumeLayout(false);
            this.menu_panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hornBtnPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rcBtnPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lightsBtnPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.motorBtnPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gpsBtnPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wheelsBtnPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.batteryBtnPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuBtn)).EndInit();
            this.dragpanel.ResumeLayout(false);
            this.dragpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saveConfigBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maximizeBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.minimizeBtn)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.motorCount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel menu_panel;
        private System.Windows.Forms.Panel dragpanel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button motorBtn;
        private System.Windows.Forms.PictureBox closeBtn;
        private System.Windows.Forms.PictureBox batteryBtnPic;
        private System.Windows.Forms.PictureBox saveConfigBtn;
        private System.Windows.Forms.PictureBox menuBtn;
        private System.Windows.Forms.PictureBox maximizeBtn;
        private System.Windows.Forms.PictureBox minimizeBtn;
        private System.Windows.Forms.Button hornBtn;
        private System.Windows.Forms.Button rcBtn;
        private System.Windows.Forms.Button lightBtn;
        private System.Windows.Forms.Button wheelsBtn;
        private System.Windows.Forms.Button gpsBtn;
        private System.Windows.Forms.Button batteryBtn;
        private System.Windows.Forms.PictureBox hornBtnPic;
        private System.Windows.Forms.PictureBox rcBtnPic;
        private System.Windows.Forms.PictureBox lightsBtnPic;
        private System.Windows.Forms.PictureBox motorBtnPic;
        private System.Windows.Forms.PictureBox gpsBtnPic;
        private System.Windows.Forms.PictureBox wheelsBtnPic;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.SaveFileDialog sfg;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panelMotorImage3;
        private System.Windows.Forms.ComboBox MotorCombo3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panelMotorImage2;
        private System.Windows.Forms.ComboBox MotorCombo2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panelMotorImage1;
        private System.Windows.Forms.ComboBox MotorCombo1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panelMotorImage;
        private System.Windows.Forms.ComboBox MotorCombo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.NumericUpDown motorCount;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown numericUpDown7;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.NumericUpDown numericUpDown6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown numericUpDown5;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.ComboBox wheelCombo;
        private System.Windows.Forms.Panel wheelLabel;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown numericUpDown8;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.NumericUpDown numericUpDown9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button rcToogle;
        private System.Windows.Forms.Button hornToogle;
        private System.Windows.Forms.Button gpsToogle;
    }
}