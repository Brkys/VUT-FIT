﻿namespace System_rizeni_robota
{
    partial class loginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.changeSettingsBtn = new System.Windows.Forms.Button();
            this.closeBtn = new System.Windows.Forms.Button();
            this.savedRobotSettings = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.simulateBtn = new System.Windows.Forms.Button();
            this.grabPanel = new System.Windows.Forms.Panel();
            this.newRobotBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // changeSettingsBtn
            // 
            this.changeSettingsBtn.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.changeSettingsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.changeSettingsBtn.Font = new System.Drawing.Font("Wingdings", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.changeSettingsBtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.changeSettingsBtn.Location = new System.Drawing.Point(339, 201);
            this.changeSettingsBtn.Margin = new System.Windows.Forms.Padding(0);
            this.changeSettingsBtn.Name = "changeSettingsBtn";
            this.changeSettingsBtn.Size = new System.Drawing.Size(30, 30);
            this.changeSettingsBtn.TabIndex = 1;
            this.changeSettingsBtn.Text = "|";
            this.changeSettingsBtn.UseVisualStyleBackColor = false;
            this.changeSettingsBtn.Click += new System.EventHandler(this.changeSettingsBtn_Click);
            // 
            // closeBtn
            // 
            this.closeBtn.BackColor = System.Drawing.Color.Red;
            this.closeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.closeBtn.Font = new System.Drawing.Font("Wingdings 2", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.closeBtn.Location = new System.Drawing.Point(418, 0);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(30, 30);
            this.closeBtn.TabIndex = 2;
            this.closeBtn.Text = "Ó";
            this.closeBtn.UseVisualStyleBackColor = false;
            this.closeBtn.Click += new System.EventHandler(this.CloseBtn_Click);
            // 
            // savedRobotSettings
            // 
            this.savedRobotSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.savedRobotSettings.Font = new System.Drawing.Font("OCR A Extended", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.savedRobotSettings.ForeColor = System.Drawing.Color.Black;
            this.savedRobotSettings.ItemHeight = 20;
            this.savedRobotSettings.Location = new System.Drawing.Point(64, 201);
            this.savedRobotSettings.Name = "savedRobotSettings";
            this.savedRobotSettings.Size = new System.Drawing.Size(273, 28);
            this.savedRobotSettings.TabIndex = 3;
            this.savedRobotSettings.Text = "Select settings ...";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("OCR A Extended", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(94, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(262, 66);
            this.label1.TabIndex = 4;
            this.label1.Text = "RoboUI";
            // 
            // simulateBtn
            // 
            this.simulateBtn.BackColor = System.Drawing.SystemColors.Highlight;
            this.simulateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.simulateBtn.Font = new System.Drawing.Font("Wingdings 3", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.simulateBtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.simulateBtn.Location = new System.Drawing.Point(368, 201);
            this.simulateBtn.Margin = new System.Windows.Forms.Padding(0);
            this.simulateBtn.Name = "simulateBtn";
            this.simulateBtn.Size = new System.Drawing.Size(30, 30);
            this.simulateBtn.TabIndex = 5;
            this.simulateBtn.Text = "u";
            this.simulateBtn.UseVisualStyleBackColor = false;
            this.simulateBtn.Click += new System.EventHandler(this.simulateBtn_Click);
            // 
            // grabPanel
            // 
            this.grabPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.grabPanel.Location = new System.Drawing.Point(-3, 0);
            this.grabPanel.Name = "grabPanel";
            this.grabPanel.Size = new System.Drawing.Size(421, 30);
            this.grabPanel.TabIndex = 6;
            this.grabPanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.grabPanel_MouseMove);
            // 
            // newRobotBtn
            // 
            this.newRobotBtn.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.newRobotBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.newRobotBtn.Font = new System.Drawing.Font("OCR A Extended", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newRobotBtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.newRobotBtn.Location = new System.Drawing.Point(157, 254);
            this.newRobotBtn.Name = "newRobotBtn";
            this.newRobotBtn.Size = new System.Drawing.Size(129, 46);
            this.newRobotBtn.TabIndex = 8;
            this.newRobotBtn.Text = "New robot settings";
            this.newRobotBtn.UseVisualStyleBackColor = false;
            this.newRobotBtn.Click += new System.EventHandler(this.newRobotBtn_Click);
            // 
            // loginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(448, 397);
            this.Controls.Add(this.newRobotBtn);
            this.Controls.Add(this.grabPanel);
            this.Controls.Add(this.simulateBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.savedRobotSettings);
            this.Controls.Add(this.closeBtn);
            this.Controls.Add(this.changeSettingsBtn);
            this.Name = "loginForm";
            this.Text = "loginForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button changeSettingsBtn;
        private System.Windows.Forms.Button closeBtn;
        private System.Windows.Forms.ComboBox savedRobotSettings;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button simulateBtn;
        private System.Windows.Forms.Panel grabPanel;
        private System.Windows.Forms.Button newRobotBtn;
    }
}