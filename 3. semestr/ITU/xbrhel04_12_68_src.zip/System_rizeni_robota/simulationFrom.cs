﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace System_rizeni_robota
{

    public partial class simulationFrom : Form
    {
        public simulationFrom()
        {
            InitializeComponent();
            map.MultiSelect = false;
            
        }

        private void minimizeBtn_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void closeBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void maximizeBtn_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
            {
                WindowState = FormWindowState.Maximized;
            }
            else if (WindowState == FormWindowState.Maximized)
            {
                WindowState = FormWindowState.Normal;
            }
        }

        private void generateMapBtn_Click(object sender, EventArgs e)
        {
            map.Rows.Clear();
            map.Columns.Clear();

            int cellSize = (map.Width -20) / System.Convert.ToInt32(numericUpDown1.Value.ToString());
            if (cellSize < 15)
                cellSize = 15;

            for (int i = 0; i < numericUpDown1.Value; i++)
            {
                if (int.Parse(numericUpDown1.Value.ToString()) != 0 && int.Parse(numericUpDown2.Value.ToString()) != 0)
                {
                    map.Columns.Add(i.ToString(), i.ToString());
                    map.Columns[i].Width = cellSize;
                    map.Columns[i].Frozen = true;
                }

            }
            for (int i = 0; i < numericUpDown2.Value; i++)
            {
                if(int.Parse(numericUpDown1.Value.ToString()) != 0 && int.Parse(numericUpDown2.Value.ToString()) != 0)
                {
                    map.Rows.Add();
                    map.Rows[i].Height = cellSize;
                }
            }
            for (int i = 0; i < numericUpDown2.Value; i++) {
                for (int j = 0; j < numericUpDown1.Value; j++) {
                    map.Rows[i].Cells[j].Style.BackColor = Color.White;
                }
            }
            map.ReadOnly = true;
            map.Update();
            map.Refresh();
        }


        ToolTip mytip = new ToolTip();
        DataGridViewCell using_cell;
        DataGridViewCell draging_cell;
        Color new_color;
        Color drag_color;
        DataGridView dg1 = new DataGridView();
        bool format = false;
        bool clear = false;
        bool was_droped = false;
        int row = 0;
        int col = 0;

        private void obstaclePixel_MouseHover(object sender, EventArgs e)
        {
            mytip.Show("Obstacle - robot can't go there", obstacleLabel);
        }

        private void endingPixel_MouseHover(object sender, EventArgs e)
        {
            mytip.Show("Robot will end there", endingLabel);
        }

        private void startPixel_MouseHover(object sender, EventArgs e)
        {
            mytip.Show("Robot will start there", startLabel);
            drag_color = Color.Green;
        }

        private void waypointPixel_MouseHover(object sender, EventArgs e)
        {
            mytip.Show("Robot must go through there", waypointLabel);
            drag_color = Color.Orange;
        }

        private void map_click(object sender, MouseEventArgs e)
        {

        }

        public List<Point> wayPoints = new List<Point>();
        private void simulationBtn_Click(object sender, EventArgs e)
        {
            if (map.Columns.Count != 0)
            {
                simulationLabel.Visible = true;
                Random rand = new Random();
                simulationLabel.Text = "Simulation took " + rand.Next(100, 1000) + " miliseconds";

                Node[,] node = new Node[map.ColumnCount, map.RowCount];
                Node tmp = new Node();
                Node tmp2 = new Node();
                Node neighbour = new Node();

                Point start = new Point();
                Point end = new Point();
                Point end_f = new Point();
                Point way = new Point();

                int topLeft = map.ColumnCount - 1;
                int topDown = map.RowCount - 1;

                int startCount = 0;
                int endCount = 0;
                int wayCount = 0;

                for (int i = 0; i < map.ColumnCount; i++) {
                    for (int j = 0; j < map.RowCount; j++) {
                        node[i, j] = new Node();
                        if (map.Rows[j].Cells[i].Style.BackColor == Color.Black)
                        {
                            node[i, j].obstacle = true;
                            node[i, j].closed = true;
                        }
                        else
                        {
                            node[i, j].obstacle = false;
                            node[i, j].closed = false;
                        }

                        node[i, j].coordinates.X = i;
                        node[i, j].coordinates.Y = j;

                        if (map.Rows[j].Cells[i].Style.BackColor == Color.Green) {
                            start.X = i;
                            start.Y = j;
                            startCount++;
                        }
                        if (map.Rows[j].Cells[i].Style.BackColor == Color.Red) {
                            end_f.X = i;
                            end_f.Y = j;
                            endCount++;
                        }
                        if (map.Rows[j].Cells[i].Style.BackColor == Color.Orange)
                        {
                            way.X = i;
                            way.Y = j;
                            wayCount++;
                        }
                    }
                }

                if (endCount != 1)
                {
                    simulationLabel.Text = "No end point set";
                    return;
                }
                if (startCount != 1)
                {
                    simulationLabel.Text = "No start point set";
                    return;
                }

                Queue<Node> nodeQ = new Queue<Node>(); // enqueue dequeue


                for (int i = 0; i <= wayCount; i++) {
                    nodeQ.Clear();
                    for (int j = 0; j < map.ColumnCount; j++)
                    {
                        for (int k = 0; k < map.RowCount; k++)
                        {
                            if (node[j, k].obstacle == false) {
                                node[j, k].closed = false;
                                node[j, k].opened = false;
                            }
                        }
                    }
                    if (wayCount == 0) {
                        end = end_f;
                    }
                    if (wayCount > 0) {
                        if (i == 0)
                        {
                            end = wayPoints[i];
                        }
                        else
                        if (i == wayCount)
                        {
                            end = end_f;
                            start = wayPoints[i - 1];
                        }
                        else {
                            start = wayPoints[i - 1];
                            end = wayPoints[i];
                        }
                    }

                    node[start.X, start.Y].opened = true;
                    nodeQ.Enqueue(node[start.X, start.Y]);

                    while (nodeQ.Count > 0) {

                        tmp = nodeQ.Dequeue();
                        node[tmp.coordinates.X, tmp.coordinates.Y].closed = true;

                        if (tmp.coordinates == end) {
                            tmp = tmp.parent;
                            while (tmp.coordinates != start) {
                                map.CurrentCell = map.Rows[tmp.coordinates.Y].Cells[tmp.coordinates.X];
                                map.CurrentCell.Style.BackColor = Color.Blue;
                                tmp = tmp.parent;
                            }
                            map.CurrentCell = map.Rows[topDown].Cells[topLeft];
                            map.CurrentCell = map.Rows[0].Cells[0];
                            break;
                        }

                        // node up
                        if (tmp.coordinates.Y > 0)
                        {
                            if (node[tmp.coordinates.X, tmp.coordinates.Y - 1].closed == false && node[tmp.coordinates.X, tmp.coordinates.Y - 1].closed == false)
                            {
                                node[tmp.coordinates.X, tmp.coordinates.Y - 1].parent = tmp;
                                node[tmp.coordinates.X, tmp.coordinates.Y - 1].opened = false;
                                nodeQ.Enqueue(node[tmp.coordinates.X, tmp.coordinates.Y - 1]);
                            }
                        }
                        // node down
                        if (tmp.coordinates.Y < topDown) {
                            if (node[tmp.coordinates.X, tmp.coordinates.Y + 1].closed == false && node[tmp.coordinates.X, tmp.coordinates.Y + 1].closed == false)
                            {
                                node[tmp.coordinates.X, tmp.coordinates.Y + 1].parent = tmp;
                                node[tmp.coordinates.X, tmp.coordinates.Y + 1].opened = true;
                                nodeQ.Enqueue(node[tmp.coordinates.X, tmp.coordinates.Y + 1]);
                            }
                        }
                        // node right
                        if (tmp.coordinates.X < topLeft)
                        {
                            if (node[tmp.coordinates.X + 1, tmp.coordinates.Y].closed == false && node[tmp.coordinates.X + 1, tmp.coordinates.Y].closed == false)
                            {
                                node[tmp.coordinates.X + 1, tmp.coordinates.Y].parent = tmp;
                                node[tmp.coordinates.X + 1, tmp.coordinates.Y].opened = true;
                                nodeQ.Enqueue(node[tmp.coordinates.X + 1, tmp.coordinates.Y]);
                            }
                        }
                        // node left
                        if (tmp.coordinates.X > 0)
                        {
                            if (node[tmp.coordinates.X - 1, tmp.coordinates.Y].closed == false && node[tmp.coordinates.X - 1, tmp.coordinates.Y].closed == false)
                            {
                                node[tmp.coordinates.X - 1, tmp.coordinates.Y].parent = tmp;
                                node[tmp.coordinates.X - 1, tmp.coordinates.Y].opened = true;
                                nodeQ.Enqueue(node[tmp.coordinates.X - 1, tmp.coordinates.Y]);
                            }
                        }
                    }
                    //return;
                }
            }
            else
            {
                MessageBox.Show("There is no generated map");
            }
        }

        private void map_click(object sender, DataGridViewCellMouseEventArgs e)
        {
            row = e.RowIndex;
            col = e.ColumnIndex;
            map.CurrentCell = map.Rows[e.RowIndex].Cells[e.ColumnIndex];

            if (map.CurrentCell.Style.BackColor == Color.Black)
            {
                clear = true;
                map.CurrentCell.Style.BackColor = Color.White;
            }
            else {
                format = true;
                map.CurrentCell.Style.BackColor = Color.Black;
            }

            int topLeft = map.ColumnCount - 1;
            int topDown = map.RowCount - 1;
            map.CurrentCell = map.Rows[topDown].Cells[topLeft];
            map.CurrentCell = map.Rows[0].Cells[0];
        }



        // some deep shit down here
        private void map_CellMouseMove(object sender, DataGridViewCellMouseEventArgs e)
        {
            row = e.RowIndex;
            col = e.ColumnIndex;
            map.CurrentCell = map.Rows[e.RowIndex].Cells[e.ColumnIndex];

            if(was_droped)
            {
                map.CurrentCell.Style.BackColor = drag_color;
                was_droped = false;
                map.CurrentCell = map.Rows[0].Cells[0];
                if (drag_color == Color.Orange)
                {
                    Point p = new Point();
                    p.X = col;
                    p.Y = row;
                    wayPoints.Add(p);
                }
            }
        }



        // drag for endingpoint
        private void dragButton_MouseDown(object sender, MouseEventArgs e)
        {
            dragEndButton.DoDragDrop(dragEndButton.Text, DragDropEffects.Copy | DragDropEffects.Move);
            drag_color = Color.Red;
        }



        // drop and enter event handler for DATAGRIDVIEW
        private void map_DragDrop(object sender, DragEventArgs e)
        {
            was_droped = true;
        }
        private void map_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
            else
                e.Effect = DragDropEffects.None;
        }

        // drag for start point
        private void dragStartButton_MouseDown(object sender, MouseEventArgs e)
        {
            dragEndButton.DoDragDrop(dragEndButton.Text, DragDropEffects.Copy | DragDropEffects.Move);
            drag_color = Color.Green;
        }

        private void dragWaypoint_MouseDown(object sender, MouseEventArgs e)
        {
            dragEndButton.DoDragDrop(dragEndButton.Text, DragDropEffects.Copy | DragDropEffects.Move);
            drag_color = Color.Orange;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < map.ColumnCount; i++)
            {
                for (int j = 0; j < map.RowCount; j++)
                {
                    map.Rows[j].Cells[i].Style.BackColor = Color.White;
                    wayPoints.Clear();
                }
            }
        }

    }

    public class Node
    {
        public bool opened;
        public bool closed;
        public bool obstacle;
        public Point coordinates;
        public Node parent;
    }
}
