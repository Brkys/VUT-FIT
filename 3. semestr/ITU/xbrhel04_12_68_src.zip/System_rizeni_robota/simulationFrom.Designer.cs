﻿namespace System_rizeni_robota
{
    partial class simulationFrom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.map = new System.Windows.Forms.DataGridView();
            this.dragpanel = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.closeBtn = new System.Windows.Forms.PictureBox();
            this.maximizeBtn = new System.Windows.Forms.PictureBox();
            this.minimizeBtn = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.generateMapBtn = new System.Windows.Forms.Button();
            this.obstaclePixel = new System.Windows.Forms.PictureBox();
            this.obstacleLabel = new System.Windows.Forms.Label();
            this.endingLabel = new System.Windows.Forms.Label();
            this.endingPixel = new System.Windows.Forms.PictureBox();
            this.startLabel = new System.Windows.Forms.Label();
            this.startPixel = new System.Windows.Forms.PictureBox();
            this.waypointLabel = new System.Windows.Forms.Label();
            this.waypointPixel = new System.Windows.Forms.PictureBox();
            this.simulationBtn = new System.Windows.Forms.Button();
            this.simulationLabel = new System.Windows.Forms.Label();
            this.dragEndButton = new System.Windows.Forms.Button();
            this.dragStartButton = new System.Windows.Forms.Button();
            this.dragWaypoint = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.map)).BeginInit();
            this.dragpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maximizeBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.minimizeBtn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.obstaclePixel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.endingPixel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.startPixel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.waypointPixel)).BeginInit();
            this.SuspendLayout();
            // 
            // map
            // 
            this.map.AllowDrop = true;
            this.map.AllowUserToAddRows = false;
            this.map.AllowUserToDeleteRows = false;
            this.map.AllowUserToResizeColumns = false;
            this.map.AllowUserToResizeRows = false;
            this.map.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.map.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.map.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.map.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.map.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.map.ColumnHeadersVisible = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.map.DefaultCellStyle = dataGridViewCellStyle1;
            this.map.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.map.Location = new System.Drawing.Point(12, 33);
            this.map.Name = "map";
            this.map.RowHeadersVisible = false;
            this.map.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.map.Size = new System.Drawing.Size(971, 477);
            this.map.TabIndex = 0;
            this.map.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.map_click);
            this.map.CellMouseMove += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.map_CellMouseMove);
            this.map.DragDrop += new System.Windows.Forms.DragEventHandler(this.map_DragDrop);
            this.map.DragEnter += new System.Windows.Forms.DragEventHandler(this.map_DragEnter);
            // 
            // dragpanel
            // 
            this.dragpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.dragpanel.Controls.Add(this.pictureBox1);
            this.dragpanel.Controls.Add(this.closeBtn);
            this.dragpanel.Controls.Add(this.maximizeBtn);
            this.dragpanel.Controls.Add(this.minimizeBtn);
            this.dragpanel.Controls.Add(this.label1);
            this.dragpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.dragpanel.Location = new System.Drawing.Point(0, 0);
            this.dragpanel.Margin = new System.Windows.Forms.Padding(1);
            this.dragpanel.Name = "dragpanel";
            this.dragpanel.Size = new System.Drawing.Size(995, 29);
            this.dragpanel.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Image = global::System_rizeni_robota.Properties.Resources.RoboUI;
            this.pictureBox1.Location = new System.Drawing.Point(0, 1);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(126, 28);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // closeBtn
            // 
            this.closeBtn.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.closeBtn.BackColor = System.Drawing.Color.Firebrick;
            this.closeBtn.Image = global::System_rizeni_robota.Properties.Resources.Close_Window_32px;
            this.closeBtn.Location = new System.Drawing.Point(968, 0);
            this.closeBtn.Margin = new System.Windows.Forms.Padding(1);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(26, 29);
            this.closeBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.closeBtn.TabIndex = 4;
            this.closeBtn.TabStop = false;
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // maximizeBtn
            // 
            this.maximizeBtn.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.maximizeBtn.BackColor = System.Drawing.Color.Transparent;
            this.maximizeBtn.Image = global::System_rizeni_robota.Properties.Resources.Maximize_Window_32px;
            this.maximizeBtn.Location = new System.Drawing.Point(942, 0);
            this.maximizeBtn.Margin = new System.Windows.Forms.Padding(1);
            this.maximizeBtn.Name = "maximizeBtn";
            this.maximizeBtn.Size = new System.Drawing.Size(26, 29);
            this.maximizeBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.maximizeBtn.TabIndex = 6;
            this.maximizeBtn.TabStop = false;
            this.maximizeBtn.Click += new System.EventHandler(this.maximizeBtn_Click);
            // 
            // minimizeBtn
            // 
            this.minimizeBtn.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.minimizeBtn.BackColor = System.Drawing.Color.Transparent;
            this.minimizeBtn.Image = global::System_rizeni_robota.Properties.Resources.Minimize_Window_32px;
            this.minimizeBtn.Location = new System.Drawing.Point(917, 0);
            this.minimizeBtn.Margin = new System.Windows.Forms.Padding(1);
            this.minimizeBtn.Name = "minimizeBtn";
            this.minimizeBtn.Size = new System.Drawing.Size(26, 29);
            this.minimizeBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.minimizeBtn.TabIndex = 5;
            this.minimizeBtn.TabStop = false;
            this.minimizeBtn.Click += new System.EventHandler(this.minimizeBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(106, 10);
            this.label1.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 0;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numericUpDown1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDown1.Location = new System.Drawing.Point(138, 530);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(59, 16);
            this.numericUpDown1.TabIndex = 4;
            this.numericUpDown1.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.numericUpDown2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDown2.Location = new System.Drawing.Point(46, 530);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(59, 16);
            this.numericUpDown2.TabIndex = 5;
            this.numericUpDown2.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // generateMapBtn
            // 
            this.generateMapBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.generateMapBtn.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.generateMapBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.generateMapBtn.Font = new System.Drawing.Font("Century Gothic", 11.1F);
            this.generateMapBtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.generateMapBtn.Location = new System.Drawing.Point(46, 552);
            this.generateMapBtn.Name = "generateMapBtn";
            this.generateMapBtn.Size = new System.Drawing.Size(151, 46);
            this.generateMapBtn.TabIndex = 9;
            this.generateMapBtn.Text = "Generate map";
            this.generateMapBtn.UseVisualStyleBackColor = false;
            this.generateMapBtn.Click += new System.EventHandler(this.generateMapBtn_Click);
            // 
            // obstaclePixel
            // 
            this.obstaclePixel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.obstaclePixel.BackColor = System.Drawing.Color.Black;
            this.obstaclePixel.Location = new System.Drawing.Point(847, 527);
            this.obstaclePixel.Name = "obstaclePixel";
            this.obstaclePixel.Size = new System.Drawing.Size(18, 17);
            this.obstaclePixel.TabIndex = 10;
            this.obstaclePixel.TabStop = false;
            this.obstaclePixel.MouseHover += new System.EventHandler(this.obstaclePixel_MouseHover);
            // 
            // obstacleLabel
            // 
            this.obstacleLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.obstacleLabel.AutoSize = true;
            this.obstacleLabel.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.obstacleLabel.Location = new System.Drawing.Point(871, 528);
            this.obstacleLabel.Name = "obstacleLabel";
            this.obstacleLabel.Size = new System.Drawing.Size(58, 16);
            this.obstacleLabel.TabIndex = 11;
            this.obstacleLabel.Text = "Obstacle";
            // 
            // endingLabel
            // 
            this.endingLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.endingLabel.AutoSize = true;
            this.endingLabel.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.endingLabel.Location = new System.Drawing.Point(871, 552);
            this.endingLabel.Name = "endingLabel";
            this.endingLabel.Size = new System.Drawing.Size(76, 16);
            this.endingLabel.TabIndex = 13;
            this.endingLabel.Text = "Ending point";
            // 
            // endingPixel
            // 
            this.endingPixel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.endingPixel.BackColor = System.Drawing.Color.Red;
            this.endingPixel.Location = new System.Drawing.Point(847, 551);
            this.endingPixel.Name = "endingPixel";
            this.endingPixel.Size = new System.Drawing.Size(18, 17);
            this.endingPixel.TabIndex = 12;
            this.endingPixel.TabStop = false;
            this.endingPixel.MouseHover += new System.EventHandler(this.endingPixel_MouseHover);
            // 
            // startLabel
            // 
            this.startLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.startLabel.AutoSize = true;
            this.startLabel.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.startLabel.Location = new System.Drawing.Point(871, 575);
            this.startLabel.Name = "startLabel";
            this.startLabel.Size = new System.Drawing.Size(64, 16);
            this.startLabel.TabIndex = 15;
            this.startLabel.Text = "Start point";
            // 
            // startPixel
            // 
            this.startPixel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.startPixel.BackColor = System.Drawing.Color.Green;
            this.startPixel.Location = new System.Drawing.Point(847, 574);
            this.startPixel.Name = "startPixel";
            this.startPixel.Size = new System.Drawing.Size(18, 17);
            this.startPixel.TabIndex = 14;
            this.startPixel.TabStop = false;
            this.startPixel.MouseHover += new System.EventHandler(this.startPixel_MouseHover);
            // 
            // waypointLabel
            // 
            this.waypointLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.waypointLabel.AutoSize = true;
            this.waypointLabel.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.waypointLabel.Location = new System.Drawing.Point(871, 598);
            this.waypointLabel.Name = "waypointLabel";
            this.waypointLabel.Size = new System.Drawing.Size(61, 16);
            this.waypointLabel.TabIndex = 17;
            this.waypointLabel.Text = "Waypoint";
            // 
            // waypointPixel
            // 
            this.waypointPixel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.waypointPixel.BackColor = System.Drawing.Color.DarkOrange;
            this.waypointPixel.Location = new System.Drawing.Point(847, 597);
            this.waypointPixel.Name = "waypointPixel";
            this.waypointPixel.Size = new System.Drawing.Size(18, 17);
            this.waypointPixel.TabIndex = 16;
            this.waypointPixel.TabStop = false;
            this.waypointPixel.MouseHover += new System.EventHandler(this.waypointPixel_MouseHover);
            // 
            // simulationBtn
            // 
            this.simulationBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.simulationBtn.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.simulationBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.simulationBtn.Font = new System.Drawing.Font("Century Gothic", 11.1F);
            this.simulationBtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.simulationBtn.Location = new System.Drawing.Point(671, 551);
            this.simulationBtn.Name = "simulationBtn";
            this.simulationBtn.Size = new System.Drawing.Size(151, 46);
            this.simulationBtn.TabIndex = 18;
            this.simulationBtn.Text = "Simulation";
            this.simulationBtn.UseVisualStyleBackColor = false;
            this.simulationBtn.Click += new System.EventHandler(this.simulationBtn_Click);
            // 
            // simulationLabel
            // 
            this.simulationLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.simulationLabel.AutoSize = true;
            this.simulationLabel.Location = new System.Drawing.Point(671, 530);
            this.simulationLabel.Name = "simulationLabel";
            this.simulationLabel.Size = new System.Drawing.Size(35, 13);
            this.simulationLabel.TabIndex = 19;
            this.simulationLabel.Text = "label2";
            this.simulationLabel.Visible = false;
            // 
            // dragEndButton
            // 
            this.dragEndButton.AllowDrop = true;
            this.dragEndButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dragEndButton.BackColor = System.Drawing.Color.Red;
            this.dragEndButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dragEndButton.ForeColor = System.Drawing.Color.White;
            this.dragEndButton.Location = new System.Drawing.Point(387, 548);
            this.dragEndButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dragEndButton.Name = "dragEndButton";
            this.dragEndButton.Size = new System.Drawing.Size(65, 50);
            this.dragEndButton.TabIndex = 20;
            this.dragEndButton.Text = "Drag\r\nEnding\r\nPoint";
            this.dragEndButton.UseVisualStyleBackColor = false;
            this.dragEndButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dragButton_MouseDown);
            // 
            // dragStartButton
            // 
            this.dragStartButton.AllowDrop = true;
            this.dragStartButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dragStartButton.BackColor = System.Drawing.Color.Green;
            this.dragStartButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dragStartButton.ForeColor = System.Drawing.Color.White;
            this.dragStartButton.Location = new System.Drawing.Point(467, 548);
            this.dragStartButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dragStartButton.Name = "dragStartButton";
            this.dragStartButton.Size = new System.Drawing.Size(68, 50);
            this.dragStartButton.TabIndex = 21;
            this.dragStartButton.Text = "Drag\r\nStart\r\nPoint";
            this.dragStartButton.UseVisualStyleBackColor = false;
            this.dragStartButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dragStartButton_MouseDown);
            // 
            // dragWaypoint
            // 
            this.dragWaypoint.AllowDrop = true;
            this.dragWaypoint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.dragWaypoint.BackColor = System.Drawing.Color.Orange;
            this.dragWaypoint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dragWaypoint.ForeColor = System.Drawing.Color.White;
            this.dragWaypoint.Location = new System.Drawing.Point(556, 547);
            this.dragWaypoint.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dragWaypoint.Name = "dragWaypoint";
            this.dragWaypoint.Size = new System.Drawing.Size(68, 50);
            this.dragWaypoint.TabIndex = 22;
            this.dragWaypoint.Text = "Drag\r\nWaypoint\r\n";
            this.dragWaypoint.UseVisualStyleBackColor = false;
            this.dragWaypoint.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dragWaypoint_MouseDown);
            // 
            // clearButton
            // 
            this.clearButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.clearButton.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.clearButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clearButton.Font = new System.Drawing.Font("Century Gothic", 11.1F);
            this.clearButton.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.clearButton.Location = new System.Drawing.Point(202, 552);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(151, 46);
            this.clearButton.TabIndex = 23;
            this.clearButton.Text = "Clear map";
            this.clearButton.UseVisualStyleBackColor = false;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // simulationFrom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(995, 626);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.dragWaypoint);
            this.Controls.Add(this.dragStartButton);
            this.Controls.Add(this.dragEndButton);
            this.Controls.Add(this.simulationLabel);
            this.Controls.Add(this.simulationBtn);
            this.Controls.Add(this.waypointLabel);
            this.Controls.Add(this.waypointPixel);
            this.Controls.Add(this.startLabel);
            this.Controls.Add(this.startPixel);
            this.Controls.Add(this.endingLabel);
            this.Controls.Add(this.endingPixel);
            this.Controls.Add(this.obstacleLabel);
            this.Controls.Add(this.obstaclePixel);
            this.Controls.Add(this.generateMapBtn);
            this.Controls.Add(this.numericUpDown2);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.dragpanel);
            this.Controls.Add(this.map);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "simulationFrom";
            this.Text = "simulationFrom";
            ((System.ComponentModel.ISupportInitialize)(this.map)).EndInit();
            this.dragpanel.ResumeLayout(false);
            this.dragpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maximizeBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.minimizeBtn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.obstaclePixel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.endingPixel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.startPixel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.waypointPixel)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView map;
        private System.Windows.Forms.Panel dragpanel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox closeBtn;
        private System.Windows.Forms.PictureBox maximizeBtn;
        private System.Windows.Forms.PictureBox minimizeBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Button generateMapBtn;
        private System.Windows.Forms.PictureBox obstaclePixel;
        private System.Windows.Forms.Label obstacleLabel;
        private System.Windows.Forms.Label endingLabel;
        private System.Windows.Forms.PictureBox endingPixel;
        private System.Windows.Forms.Label startLabel;
        private System.Windows.Forms.PictureBox startPixel;
        private System.Windows.Forms.Label waypointLabel;
        private System.Windows.Forms.PictureBox waypointPixel;
        private System.Windows.Forms.Button simulationBtn;
        private System.Windows.Forms.Label simulationLabel;
        private System.Windows.Forms.Button dragEndButton;
        private System.Windows.Forms.Button dragStartButton;
        private System.Windows.Forms.Button dragWaypoint;
        private System.Windows.Forms.Button clearButton;
    }
}