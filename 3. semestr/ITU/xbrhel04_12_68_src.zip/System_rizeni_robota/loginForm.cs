﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Menu;

namespace System_rizeni_robota
{
    public partial class loginForm : Form
    {
        public loginForm()
        {
            InitializeComponent();
            if (Directory.Exists(@".\Data\"))
            {
                string path = ".\\Data\\";
                string[] directoryfiles = Directory.GetFiles(@".\Data\");
                for (int i = 0; i < directoryfiles.Length; i++)
                {
                    if (directoryfiles[i].Contains(".settings"))
                        savedRobotSettings.Items.Add(Path.GetFileNameWithoutExtension(directoryfiles[i]));
                }
            }
            else
                MessageBox.Show("Data folder not found!");
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Pro pohyb bez borderu
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        //Import .dll souborů pro pohyb bez borderu
        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        private void grabPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(this.Handle, WM_NCLBUTTONDOWN, new IntPtr(HT_CAPTION), IntPtr.Zero);
            }
        }

        private void changeSettingsBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            configForm form = new configForm();
            form.BackColor = Color.Silver;
            form.ForeColor = this.ForeColor;
            form.FormBorderStyle = this.FormBorderStyle;
            form.StartPosition = this.StartPosition;
            form.StartPosition = this.StartPosition;
            form.ShowDialog();
            form = null;
            Show();
        }

        private void simulateBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            simulationFrom form = new simulationFrom();
            form.FormClosed += (s, args) => this.Close();
            form.BackColor = Color.Silver;
            form.ForeColor = this.ForeColor;
            form.FormBorderStyle = this.FormBorderStyle;
            form.StartPosition = this.StartPosition;
            form.StartPosition = this.StartPosition;
            form.Show();
        }

        private void newRobotBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            configForm form = new configForm();
            form.BackColor = Color.Silver;
            form.ForeColor = this.ForeColor;
            form.FormBorderStyle = this.FormBorderStyle;
            form.StartPosition = this.StartPosition;
            form.StartPosition = this.StartPosition;
            form.ShowDialog();
            form = null;
            Show();
        }
    }
}
