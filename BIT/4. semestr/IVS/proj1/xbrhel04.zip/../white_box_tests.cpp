//======== Copyright (c) 2017, FIT VUT Brno, All rights reserved. ============//
//
// Purpose:     White Box - Tests suite
//
// $NoKeywords: $ivs_project_1 $white_box_code.cpp
// $Author:     Zdeněk Brhel <xbrhel04@stud.fit.vutbr.cz>
// $Date:       $2017-01-04
//============================================================================//
/**
 * @file white_box_tests.cpp
 * @author JMENO PRIJMENI
 * 
 * @brief Implementace testu prace s maticemi.
 */

#include "gtest/gtest.h"
#include "white_box_code.h"

//============================================================================//
// ** ZDE DOPLNTE TESTY **
//
// Zde doplnte testy operaci nad maticemi. Cilem testovani je:
// 1. Dosahnout maximalniho pokryti kodu (white_box_code.cpp) testy.
// 2. Overit spravne chovani operaci nad maticemi v zavislosti na rozmerech 
//    matic.
//============================================================================//

using namespace ::testing;

class TestingMatrix : public Test
{
protected:
	Matrix matrix;

	Matrix Get1x1Matrix()
	{
		return Matrix();
	}

	Matrix Get4x3Matrix()
	{
		Matrix matrix = Matrix(4,3);
		matrix.set(std::vector<std::vector<double>>
		{
			{1, 2, 3},
			{-1, 3, 5},
			{3, 8, -6},
			{4, 8, -2},
		});
		return matrix;
	}

	Matrix Get3x3Matrix()
	{
		Matrix matrix = Matrix(3,3);
		matrix.set(std::vector<std::vector<double>>
		{
			{1, 2, 3},
			{4, 5, 6},
			{7, 8, 9},
		});
		return matrix;
	}

	Matrix Get4x4Matrix()
	{
		Matrix matrix = Matrix(4,4);
		matrix.set(std::vector<std::vector <double>>
		{
			{5, 6, 8, -5},
			{7, 2, -4, 2},
			{1, 2, -3, 4},
			{-7, 8, 9, 6},
		});
		return matrix;
	}

	Matrix GetDiagonalMatrix()
	{
		Matrix matrix = Matrix(3,3);
		matrix.set(std::vector<std::vector<double>>
		{
			{1, 0, 0},
			{0, 1, 0},
			{0, 0, 1},
		});
		return matrix;
	}
};

TEST_F(TestingMatrix, Constructor)
{
	EXPECT_ANY_THROW(Matrix(-1, -1));
	EXPECT_ANY_THROW(Matrix(0, 0));
	EXPECT_ANY_THROW(Matrix(25, 0));

	EXPECT_NO_THROW(Matrix(1, 1));
	EXPECT_NO_THROW(Matrix(100, 100));
	EXPECT_NO_THROW(Matrix(8,6));
}

TEST_F(TestingMatrix, Get1x1Matrix)
{
	Matrix matrix = Get1x1Matrix();
	EXPECT_TRUE(matrix.set(0, 0, 1));
	EXPECT_TRUE(matrix.set(0, 0, -1));
	EXPECT_TRUE(matrix.set(0, 0, 0));
	EXPECT_TRUE(matrix.set(0, 0, 65536));
	EXPECT_TRUE(matrix.set(0, 0, -65536));
	EXPECT_TRUE(matrix.set(0, 0, 65536.15));
	EXPECT_TRUE(matrix.set(0, 0, -65536.15));

	EXPECT_FALSE(matrix.set(8, 8, 6));
	EXPECT_FALSE(matrix.set(0, 1, 6));
	EXPECT_FALSE(matrix.set(1, 0, 6));
	EXPECT_FALSE(matrix.set(0, -1, 0));
	EXPECT_FALSE(matrix.set(-1, 0, 0));
	EXPECT_FALSE(matrix.set(65536, 65536, 65536));
}

TEST_F(TestingMatrix, Get4x3Matrix)
{
	Matrix matrix = Get4x3Matrix();
	EXPECT_FALSE(matrix.set(std::vector<std::vector<double>> {{4}, {5}, {6}}));
	EXPECT_FALSE(matrix.set(std::vector<std::vector<double>> {{1,2,3},{4,5,6},{7,8,9}}));
	EXPECT_TRUE(matrix.set(std::vector<std::vector<double>> {{1,2,3},{4,5,6},{7,8,9},{1,2,3}}));
}

TEST_F(TestingMatrix, Get4x4Matrix)
{
	Matrix matrix = Get4x4Matrix();
	EXPECT_FALSE(matrix.set(std::vector<std::vector<double>> {{4}, {5}, {6}}));
	EXPECT_FALSE(matrix.set(std::vector<std::vector<double>> {{1,2,3,4},{4,5,6,7},{7,8,9,1}}));
	EXPECT_TRUE(matrix.set(std::vector<std::vector<double>> {{1,2,3,-1},{4,5,6,-2},{7,8,9,-3},{1,2,3,-4}}));
}

TEST_F(TestingMatrix, Equalation)
{
	Matrix mat1 = Get1x1Matrix();
	Matrix mat2 = Get1x1Matrix();
	EXPECT_TRUE(mat1.operator==(mat2));
	mat1.set(0, 0, 1);
	EXPECT_FALSE(mat1.operator==(mat2));

	mat1 = Get3x3Matrix();
	mat2 = Get3x3Matrix();
	EXPECT_TRUE(mat1.operator==(mat2));

	mat1 = Get4x3Matrix();
	EXPECT_ANY_THROW(mat1.operator==(mat2));
	mat2.set(3, 3, 3);
	EXPECT_ANY_THROW(mat1.operator==(mat2));
	mat1 = Get3x3Matrix();
	mat1.set(3,3,3);
	EXPECT_TRUE(mat1.operator==(mat2));
}

TEST_F(TestingMatrix, Addition)
{
	Matrix mat1 = Get1x1Matrix();
	Matrix mat2 = Get1x1Matrix();
	mat2.set(0,0,5);
	Matrix exp = mat1 + mat2;
	EXPECT_NO_THROW(mat1 =mat1.operator+(mat2));
	EXPECT_EQ(mat1, exp);

	mat2 = Get4x3Matrix();
	EXPECT_ANY_THROW(mat1.operator+(mat2));
	
	mat1 = Get4x3Matrix();
	exp = mat1 + mat2;
	EXPECT_NO_THROW(mat1 = mat1.operator+(mat2));
	EXPECT_EQ(mat1, exp);

	//mat1 = GetDiagonalMatrix();
	//exp = mat1 + mat2;
	//EXPECT_NO_THROW(mat1 = mat1.operator+(mat2));
	//EXPECT_EQ(mat1, exp);
}

TEST_F(TestingMatrix, Multiplication)
{
	Matrix mat1 = Get1x1Matrix();
	Matrix mat2 = Get1x1Matrix();
	mat2.set(0,0,5);
	Matrix exp = mat1 * mat2;
	EXPECT_NO_THROW(mat1 = mat1.operator*(mat2));
	EXPECT_EQ(mat1, exp);

	mat2 = Get4x3Matrix();
	EXPECT_ANY_THROW(mat2.operator*(mat1));
	mat1 = Matrix(3,4);
	mat1.set(std::vector<std::vector<double>>
	{
		{1, 2, 3, 4},
		{1, 2, 3, 4},
		{1, 2, 3, 4}
	});
	exp = mat1*mat2;
	EXPECT_NO_THROW(mat2 = mat2.operator*(mat1));

	mat2 = Matrix(3,3);
	mat2.set(std::vector<std::vector<double>>
	{
		{1,2,3},
		{1,2,3},
		{1,2,3}
	});
	mat1 = Get4x3Matrix();
	EXPECT_NO_THROW(mat1 = mat1.operator*(mat2));
	exp = Matrix(4,3);
	exp.set(std::vector<std::vector<double>>
	{
		{6,12,18},
		{7,14,21},
		{5,10,15},
		{10,20,30}
	});
	EXPECT_EQ(exp, mat1);

	mat1 = Get3x3Matrix();
	mat1.set(std::vector<std::vector<double>>
	{
		{1,1,1},
		{2,2,2},
		{3,3,3}
	});
	EXPECT_NO_THROW(mat1 = mat1.operator*(2));
	exp = Matrix(3,3);
	exp.set(std::vector<std::vector<double>>
	{
		{2,2,2},
		{4,4,4},
		{6,6,6}
	});
	EXPECT_EQ(mat1, exp);
}

TEST_F(TestingMatrix, Equations)
{
	Matrix mat1 = Get4x4Matrix();
	std::vector<double> v = {0, 0, 0, 0};
	EXPECT_ANY_THROW(mat1.solveEquation({0,1,2}));
	EXPECT_NO_THROW(v = mat1.solveEquation({0,1,2,3}));
	
	mat1 = GetDiagonalMatrix();
	EXPECT_NO_THROW(v = mat1.solveEquation({1,1,1}));
	std::vector<double> exp = {1, 1, 1};
	EXPECT_EQ(exp,v);

	mat1 = Get4x3Matrix();
	EXPECT_ANY_THROW(mat1.solveEquation({1, 2, 3}));
	EXPECT_ANY_THROW(mat1.solveEquation({}));
	mat1 = Get1x1Matrix();
	EXPECT_ANY_THROW(mat1.solveEquation({1,2,3}));

}

TEST_F(TestingMatrix, 1x1Matrix)
{
	Matrix mat1 = Matrix();
	mat1.set(0,0,2);
	EXPECT_TRUE(mat1.solveEquation({2}) == std::vector<double> {1});
}

TEST_F(TestingMatrix, 3x3Matrix)
{
	Matrix mat1 = Get3x3Matrix();
	mat1.set(std::vector<std::vector<double>>
	{
		{1,1,0},
		{0,1,0},
		{0,0,1}
	});
	std::vector<double> exp = std::vector<double> {0.5,0.5,1};
	EXPECT_EQ(mat1.solveEquation({1,0.5,1}), exp);
}
/*** Konec souboru white_box_tests.cpp ***/