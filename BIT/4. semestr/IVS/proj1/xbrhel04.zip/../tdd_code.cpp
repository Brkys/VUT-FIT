//======== Copyright (c) 2017, FIT VUT Brno, All rights reserved. ============//
//
// Purpose:     Test Driven Development - priority queue code
//
// $NoKeywords: $ivs_project_1 $tdd_code.cpp
// $Author:     Zdeněk Brhel <xbrhel04@stud.fit.vutbr.cz>
// $Date:       $2017-01-04
//============================================================================//
/**
 * @file tdd_code.cpp
 * @author JMENO PRIJMENI
 * 
 * @brief Implementace metod tridy prioritni fronty.
 */

#include <stdlib.h>
#include <stdio.h>

#include "tdd_code.h"

//============================================================================//
// ** ZDE DOPLNTE IMPLEMENTACI **
//
// Zde doplnte implementaci verejneho rozhrani prioritni fronty (Priority Queue)
// 1. Verejne rozhrani fronty specifikovane v: tdd_code.h (sekce "public:")
//    - Konstruktor (PriorityQueue()), Destruktor (~PriorityQueue())
//    - Metody Insert/Remove/Find a GetHead
//    - Pripadne vase metody definovane v tdd_code.h (sekce "protected:")
//
// Cilem je dosahnout plne funkcni implementace prioritni fronty implementovane
// pomoci tzv. "double-linked list", ktera bude splnovat dodane testy 
// (tdd_tests.cpp).
//============================================================================//

PriorityQueue::PriorityQueue()
{
	root = NULL;
}

PriorityQueue::~PriorityQueue()
{
	PriorityQueue::Element_t *element = GetHead();
	while(element != NULL)
	{
		PriorityQueue::Element_t *tmp = element;
		element = element->pNext;
		delete tmp;
	}
}

void PriorityQueue::Insert(int value)
{
	PriorityQueue::Element_t *element = GetHead();
	PriorityQueue::Element_t *tmp = NULL;
	while(element != NULL) //vyhledávání - 12456, vkládám trojku
	{
		if(value >= element->value) //podmínka bude platit pro číslo 2
			tmp = element; //uchovám pointer na 2, budu vkládat vždy napravo od pointeru
		element = element->pNext; //"iterace" ve frontě
	}
	if(tmp == NULL)
	{
		PriorityQueue::Element_t *newElement = new PriorityQueue::Element_t;
		newElement->pNext = GetHead();
		newElement->pPrev = NULL;
		newElement->value = value;
		if(root != NULL)
			root->pPrev = newElement;
		root = newElement;
	}
	else
	{
		PriorityQueue::Element_t *newElement = new PriorityQueue::Element_t;
		newElement->value = value;
		newElement->pPrev = tmp;
		newElement->pNext = tmp->pNext;
		if(tmp->pNext != NULL)
			tmp->pNext->pPrev = newElement;
		tmp->pNext = newElement;
	}

	/*if(tmp == NULL && root == NULL) //je li fronta prázdná
	{
		PriorityQueue::Element_t *newElement = new PriorityQueue::Element_t;
		newElement->pNext = GetHead();
		newElement->pPrev = NULL;
		newElement->value = value;
		root = newElement;
		return;
	}
	else if(tmp == NULL && root != NULL)
	{
		PriorityQueue::Element_t *newElement = new PriorityQueue::Element_t;
		newElement->pNext = root;
		newElement->pPrev = NULL;
		root->pPrev = newElement;
		newElement->value = value;
		root = newElement;
		return;	
	}
	//je li ve frontě pouze jeden element, nebo je element vkládán na konec fronty
	if((tmp->pPrev == NULL && tmp->pNext == NULL) || (tmp->pPrev != NULL && tmp->pNext == NULL)) {
		PriorityQueue::Element_t *newElement = new PriorityQueue::Element_t;
		newElement->value = value; 
		newElement->pNext = tmp->pNext;
		newElement->pPrev = tmp;
		tmp->pNext = newElement;
	}
	//je li prvek vkládán někam doprostřed fronty, nebo je prvek vkádán na začátek
	else if(tmp->pPrev != NULL && tmp->pNext != NULL || (tmp->pPrev == NULL && tmp->pNext != NULL)) {
		PriorityQueue::Element_t *newElement = new PriorityQueue::Element_t;
		newElement->value = value;
		newElement->pNext = tmp->pNext;
		newElement->pPrev = tmp;
		tmp->pNext->pPrev = newElement;
		tmp->pNext = newElement;
	}
	return;*/

}

bool PriorityQueue::Remove(int value)
{
	PriorityQueue::Element_t *element = Find(value);
	if(element == NULL) //element neexistuje
		return false;
	if(element->pPrev != NULL && element->pNext != NULL) //je někde uprostřed
	{
		element->pPrev->pNext = element->pNext;
		element->pNext->pPrev = element->pPrev;		
	}
	else if(element->pPrev == NULL && element->pNext != NULL) //je první
	{
		element->pNext->pPrev = NULL;
		root = element->pNext;
	}
	else if (element->pPrev != NULL && element->pNext == NULL) //poslední
	{
		element->pPrev->pNext = NULL;
	}
	else if(element->pPrev == NULL && element->pNext == NULL) //je jen jeden prvek ve frontě
	{
		root = NULL;
	}
	delete element;
	return true;
}

PriorityQueue::Element_t *PriorityQueue::Find(int value)
{
	PriorityQueue::Element_t *element = GetHead();
	while(element != NULL)
	{
		if(element->value == value)
			return element;
		element = element->pNext;
	}
    return NULL;
}

PriorityQueue::Element_t *PriorityQueue::GetHead()
{
    return root;
}

/*** Konec souboru tdd_code.cpp ***/
