//======== Copyright (c) 2017, FIT VUT Brno, All rights reserved. ============//
//
// Purpose:     Red-Black Tree - public interface tests
//
// $NoKeywords: $ivs_project_1 $black_box_tests.cpp
// $Author:     Zdeněk Brhel <xbrhel04@stud.fit.vutbr.cz>
// $Date:       $2017-01-04
//============================================================================//
/**
 * @file black_box_tests.cpp
 * @author JMENO PRIJMENI
 * 
 * @brief Implementace testu binarniho stromu.
 */

#include <vector>

#include "gtest/gtest.h"

#include "red_black_tree.h"

//============================================================================//
// ** ZDE DOPLNTE TESTY **
//
// Zde doplnte testy Red-Black Tree, testujte nasledujici:
// 1. Verejne rozhrani stromu
//    - InsertNode/DeleteNode a FindNode
//    - Chovani techto metod testuje pro prazdny i neprazdny strom.
// 2. Axiomy (tedy vzdy platne vlastnosti) Red-Black Tree:
//    - Vsechny listove uzly stromu jsou *VZDY* cerne.
//    - Kazdy cerveny uzel muze mit *POUZE* cerne potomky.
//    - Vsechny cesty od kazdeho listoveho uzlu ke koreni stromu obsahuji
//      *STEJNY* pocet cernych uzlu.
//============================================================================//

using namespace ::testing;

class NonEmptyTree : public Test
{
public:
    BinaryTree tree;
	int numberofvalues = 9;
    int values[9] = { 1, 4, 8, 15, 16, 23, 42, 6, 12 };
    BinaryTree::Node_t *nodes[9];    
    std::pair<bool, BinaryTree::Node_t *> result;
    
    virtual void SetUp() {
        for(int i = 0; i < numberofvalues; ++i)
        {
            result = tree.InsertNode(values[i]);
            nodes[i] = result.second;
        }
    }
};

class TreeAxioms : public Test
{
public:
	BinaryTree tree;
	int numberofvalues = 9;
    int values[9] = { 1, 4, 8, 15, 16, 23, 42, 6, 12 };
    BinaryTree::Node_t *nodes[9];    
    std::pair<bool, BinaryTree::Node_t *> result;
    
    virtual void SetUp() {
        for(int i = 0; i < numberofvalues; ++i)
        {
            result = tree.InsertNode(values[i]);
            nodes[i] = result.second;
        }
    }
};

class EmptyTree : public Test
{
public:
	BinaryTree tree;
	std::pair<bool, BinaryTree::Node_t *> result;
};

TEST_F(NonEmptyTree, Insert)
{
	for (int i = 0; i < numberofvalues; i++)
	{
		EXPECT_EQ(nodes[i]->key, values[i]); //kontrola, jestli uzly souhlasí s hodnotama
	}

	//Vložení existujícího uzlu
	result = tree.InsertNode(1);
	BinaryTree::Node_t *tempnode = result.second;
	ASSERT_TRUE(tempnode != NULL); //kontola ukazatele
	EXPECT_FALSE(result.first); //kontrola, že prvek již existuje
	EXPECT_EQ(tempnode->key, 1); //kontrola, že klíč uzlu je 1
	EXPECT_EQ(tempnode->color, BinaryTree::BLACK); //ověření barvy

	//Ověření stavu levého a pravého potomka tohoto uzlu
	//levý
	BinaryTree::Node_t *tmp1 = tempnode->pLeft;
	ASSERT_TRUE(tmp1 != NULL);
	//pravý
	tmp1 = tempnode->pRight;
	ASSERT_TRUE(tmp1 != NULL);

	//Vložení nového uzlu a ověření správnosti jeho vlastností
	std::pair<bool, BinaryTree::Node_t *> result = tree.InsertNode(5);
	BinaryTree::Node_t *tempnode2 = result.second;
	ASSERT_TRUE(tempnode2 != NULL);
	EXPECT_TRUE(result.first);
	EXPECT_EQ(tempnode2->color, BinaryTree::RED);
	ASSERT_TRUE(tempnode2->pParent != NULL);
	EXPECT_EQ(tempnode2->key, 5);
	EXPECT_EQ(tempnode2->pParent->key,6);
	EXPECT_EQ(tempnode2->pParent->color, BinaryTree::BLACK);
}

TEST_F(EmptyTree, Insert)
{
	//Vložení prvního uzlu a ověření jeho správnosti
	result = tree.InsertNode(1);
	BinaryTree::Node_t *tempnode = result.second;
	ASSERT_TRUE(tempnode != NULL); //kontrola ukazatele
	EXPECT_EQ(tempnode->key, 1); //kontrola klíče
	EXPECT_EQ(tempnode->color, BinaryTree::BLACK); //kontrola barvy
	EXPECT_TRUE(result.first); //ověření, že prvek ještě neexistuje
	EXPECT_TRUE(tempnode->pParent == NULL); //kontrola rodiče

	//Ověření správnosti levého a pravého potomka
	//levý potomek
	BinaryTree::Node_t *tmpleft = tempnode->pLeft;
	ASSERT_TRUE(tempnode != NULL); //kontrola ukazatele
	EXPECT_EQ(tmpleft->pParent->key, 1); //kontrola hodnoty rodiče
	EXPECT_EQ(tmpleft->color, BinaryTree::BLACK); //kontrola barvy
	EXPECT_TRUE(tmpleft->pRight == NULL); //kontrola ukazatele pravého potomka
	EXPECT_TRUE(tmpleft->pLeft == NULL); //kontrola ukazatele levého potomka
	EXPECT_TRUE(tmpleft->pParent != NULL); //kontrola rodiče
	//pravý potomek
	BinaryTree::Node_t *tmpright = tempnode->pRight; //to samé, akorát pro pravého
	ASSERT_TRUE(tmpright != NULL); 
	EXPECT_EQ(tmpright->pParent->key, 1);
	EXPECT_EQ(tmpright->color, BinaryTree::BLACK);
	EXPECT_TRUE(tmpright->pRight == NULL);
	EXPECT_TRUE(tmpright->pLeft == NULL);
	EXPECT_TRUE(tmpright->pParent != NULL);

	//Vložení uzlu s hodnotou 4 a ověření jeho správnosti
	result = tree.InsertNode(4);	//Kontrola probíhá pořád stejně..
	BinaryTree::Node_t *tempnode2 = result.second;
	ASSERT_TRUE(tempnode2 != NULL);
	EXPECT_EQ(tempnode2->pParent->key, 1);
	EXPECT_EQ(tempnode2->color, BinaryTree::RED);
	EXPECT_TRUE(result.first);
	EXPECT_EQ(tempnode2->key, 4);
	ASSERT_TRUE(tempnode2->pParent != NULL);

	//Ověření levého a pravého potomka tohoto uzlu
	//pravý
	BinaryTree::Node_t *right2 = tempnode2->pRight;
	ASSERT_TRUE(right2 != NULL);
	EXPECT_EQ(right2->pParent->key, 4);
	EXPECT_EQ(right2->color, BinaryTree::BLACK);
	EXPECT_TRUE(right2->pRight == NULL);
	EXPECT_TRUE(right2->pLeft == NULL);
	EXPECT_TRUE(right2->pParent != NULL);
	//levý
	BinaryTree::Node_t *left2 = tempnode2->pLeft;
	ASSERT_TRUE(left2 != NULL);
	EXPECT_EQ(left2->color, BinaryTree::BLACK);
	EXPECT_TRUE(left2->pLeft == NULL);
	EXPECT_TRUE(left2->pParent != NULL);
	EXPECT_EQ(left2->pParent->key, 4);

	//Ověření hodnoty a návaznosti potomka
	EXPECT_EQ(tempnode->pRight, tempnode2);
	EXPECT_EQ(tempnode->pRight->key, 4);

	//Vložení uzlu s hodnotou 0 a ověření jeho stavu
	result = tree.InsertNode(0);
	BinaryTree::Node_t *zeronode = result.second;
	EXPECT_TRUE(result.first);
	ASSERT_TRUE(zeronode != NULL);
	EXPECT_EQ(zeronode->pParent->key, 1);
	EXPECT_EQ(zeronode->color, BinaryTree::RED);
	EXPECT_EQ(zeronode->key, 0);
	ASSERT_TRUE(zeronode->pParent != NULL);

	//Vložení existujícího uzlu
	result = tree.InsertNode(1);
	BinaryTree::Node_t *existnode = result.second;
	ASSERT_TRUE(existnode != NULL);
	EXPECT_TRUE(existnode == tempnode);
	EXPECT_FALSE(result.first);
	ASSERT_TRUE(existnode->pParent == NULL);
	EXPECT_EQ(existnode->key, 1);

	//Vložení uzlu s zápornou hodnotou a ověření jeho správnosti
	std::pair<bool, BinaryTree::Node_t *> result = tree.InsertNode(-1);
	BinaryTree::Node_t *negnode = result.second;
	EXPECT_TRUE(result.first);
	ASSERT_TRUE(negnode != NULL);
	ASSERT_TRUE(negnode->pParent == zeronode);
	EXPECT_EQ(negnode->pParent->key, 0);
	EXPECT_EQ(negnode->color, BinaryTree::RED);
	EXPECT_EQ(negnode->key, -1);
}

TEST_F(NonEmptyTree, FindNode)
{
	EXPECT_FALSE(tree.FindNode(0) != NULL);
	EXPECT_FALSE(tree.FindNode(-1) != NULL);
	EXPECT_FALSE(tree.FindNode(-5) != NULL);
	EXPECT_FALSE(tree.FindNode(500) != NULL);
	for (int i = 0; i < numberofvalues; i++)
	{
		EXPECT_TRUE(tree.FindNode(values[i]) != NULL); //hledají se všechny existující hodnoty ve stromu
	}
}

TEST_F(EmptyTree, FindNode)
{
	int values[9] = { 1, 4, 8, 15, 16, 23, 42, 6, 12 };
	EXPECT_FALSE(tree.FindNode(0) != NULL);
	EXPECT_FALSE(tree.FindNode(-1) != NULL);
	EXPECT_FALSE(tree.FindNode(-5) != NULL);
	EXPECT_FALSE(tree.FindNode(500) != NULL);
	for(int i = 0; i < 9; ++i)
	{
		EXPECT_TRUE(tree.FindNode(values[i]) == NULL);
	}
}

TEST_F(NonEmptyTree, DeleteNode)
{
	EXPECT_TRUE(tree.DeleteNode(12));
	for(int i = 0; i < numberofvalues; i++)
	{
		if(values[i] == 12)
			EXPECT_FALSE(tree.DeleteNode(values[i]));
		else
			EXPECT_TRUE(tree.DeleteNode(values[i]));
	}
	EXPECT_FALSE(tree.DeleteNode(15));
	EXPECT_FALSE(tree.DeleteNode(0));
	EXPECT_FALSE(tree.DeleteNode(-1));
}

TEST_F(EmptyTree, DeleteNode)
{
	int values[9] = { 1, 4, 8, 15, 16, 23, 42, 6, 12 }; 
	for(int i = 0; i < 9; i++)
	{
		EXPECT_FALSE(tree.DeleteNode(values[i]));
	}
	EXPECT_FALSE(tree.DeleteNode(-1));

}

TEST_F(TreeAxioms, Axiom1)
{
	std::vector<Node_t *> outLeafNodes;
	tree.GetLeafNodes(outLeafNodes);
	for(BinaryTree::Node_t *node : outLeafNodes) //ve všech listech kontroluji, zda jsou černé
	{
		ASSERT_TRUE(node->pRight == NULL);
		ASSERT_TRUE(node->pLeft == NULL);
		ASSERT_TRUE(node->color == BinaryTree::BLACK);
	}
}

TEST_F(TreeAxioms, Axiom2)
{
	std::vector<Node_t *> outAllNodes;
	tree.GetAllNodes(outAllNodes); 
	for (BinaryTree::Node_t *node : outAllNodes) //ve všech uzlích kontroluju, že červené uzly mají pouze černé potomky
	{
		if(node->color = BinaryTree::RED)
		{
			ASSERT_TRUE(node->pRight != NULL);
			ASSERT_TRUE(node->pLeft != NULL);
			EXPECT_TRUE(node->pLeft->color == BinaryTree::BLACK);
			EXPECT_TRUE(node->pRight->color == BinaryTree::BLACK);
		}
	}
}

TEST_F(TreeAxioms, Axiom3)
{
	std::vector<Node_t *> outLeafNodes;
	tree.GetLeafNodes(outLeafNodes); //všechny uzly
	int i[2] = {0, 0}; //pomocné proměnné (aktuální černé uzly, předchozí černé uzly)
	BinaryTree::Node_t *tmpNode; //pomocný uzel (aktuální)

	for (BinaryTree::Node_t *node : outLeafNodes) //ve všech listových
	{
		i[0] = 0; //nastavuji aktuální černé listy na 0 (ještě jsem žádný nenašel)
		tmpNode = node; //nastavuji aktuální uzel na uzel
		while (tmpNode != NULL) 
		{
			if(tmpNode->color == BinaryTree::BLACK)
				i[0]++;
			tmpNode = tmpNode->pParent; //procházím kadždý uzel od listů až ke kořenu
		}
		if (i[1] != 0)
			EXPECT_EQ(i[0], i[1]);
		i[1] = i[0];
	}
}
/*** Konec souboru black_box_tests.cpp ***/
